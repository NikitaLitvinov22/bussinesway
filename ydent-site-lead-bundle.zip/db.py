"""SQLite storage layer. Один файл БД, без внешней СУБД — достаточно для
одного пользователя на слабом VPS."""
import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

DB_PATH = Path(__file__).parent / "data.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS calls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    calltouch_id TEXT UNIQUE,
    phone TEXT,
    phone_norm TEXT,
    source TEXT,
    medium TEXT,
    campaign TEXT,
    term TEXT,
    content TEXT,
    city TEXT,
    call_phase TEXT,
    status TEXT,
    is_unique INTEGER,
    is_target INTEGER,
    duration INTEGER,
    started_at TEXT,
    record_url TEXT,
    raw_json TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_calls_phone_norm ON calls(phone_norm);
CREATE INDEX IF NOT EXISTS idx_calls_started_at ON calls(started_at);

CREATE TABLE IF NOT EXISTS crm_clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    crm_id INTEGER UNIQUE,
    phone TEXT,
    phone_norm TEXT,
    name TEXT,
    raw_json TEXT,
    updated_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_clients_phone_norm ON crm_clients(phone_norm);

CREATE TABLE IF NOT EXISTS crm_visits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    crm_id INTEGER UNIQUE,
    client_crm_id INTEGER,
    resource_id INTEGER,
    visit_datetime TEXT,
    total_price REAL,
    is_paid INTEGER,
    attendance TEXT,
    deleted INTEGER DEFAULT 0,
    services_json TEXT,
    raw_json TEXT,
    updated_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_visits_client ON crm_visits(client_crm_id);
CREATE INDEX IF NOT EXISTS idx_visits_datetime ON crm_visits(visit_datetime);

CREATE TABLE IF NOT EXISTS crm_payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    crm_id INTEGER UNIQUE,
    client_crm_id INTEGER,
    visit_crm_id INTEGER,
    amount REAL,
    payment_method TEXT,
    payment_type TEXT,
    payment_date TEXT,
    raw_json TEXT,
    updated_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_payments_client ON crm_payments(client_crm_id);
CREATE INDEX IF NOT EXISTS idx_payments_date ON crm_payments(payment_date);

CREATE TABLE IF NOT EXISTS ad_spend (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel TEXT NOT NULL,        -- 'yandex_direct' | '2gis' | 'yandex_maps' | ...
    period_date TEXT NOT NULL,    -- YYYY-MM-DD (day) или YYYY-MM-01 для ручного месячного ввода
    amount REAL NOT NULL,
    source TEXT DEFAULT 'manual', -- 'manual' | 'api'
    updated_at TEXT DEFAULT (datetime('now')),
    UNIQUE(channel, period_date, source)
);

CREATE TABLE IF NOT EXISTS crm_employees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    crm_id INTEGER UNIQUE,
    firstname TEXT,
    lastname TEXT,
    patronymic TEXT,
    position TEXT,
    is_fired INTEGER DEFAULT 0,
    is_deleted INTEGER DEFAULT 0,
    raw_json TEXT,
    updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS dormant_outreach (
    client_crm_id INTEGER PRIMARY KEY,
    status TEXT DEFAULT 'new',   -- 'new' | 'contacted' | 'no_answer' | 'booked'
    note TEXT,
    updated_at TEXT DEFAULT (datetime('now'))
);

-- Заявки с форм сайта (Tilda) — приходят отдельным вебхуком от звонков
-- Calltouch, потому что это два разных источника лидов (звонок vs форма).
-- tilda_tranid — уникальный ID заявки от самой Tilda (защита от дублей,
-- как calltouch_id у звонков); если Tilda его не прислала — генерируем
-- свой (см. upsert_site_lead).
CREATE TABLE IF NOT EXISTS site_leads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tilda_tranid TEXT UNIQUE,
    form_id TEXT,          -- formid — какой блок/форма на сайте прислал заявку
    page_url TEXT,         -- страница, с которой отправлена форма (если Tilda её передаёт)
    name TEXT,
    phone TEXT,
    phone_norm TEXT,
    message TEXT,          -- "опишите проблему" и т.п., если в форме есть такое поле
    source TEXT,           -- utm_source — из скрытых полей, которые заполняет наш JS на сайте
    medium TEXT,
    campaign TEXT,
    term TEXT,
    content TEXT,
    visitor_id TEXT,       -- наш собственный cookie-идентификатор посетителя
    raw_json TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_site_leads_phone_norm ON site_leads(phone_norm);
CREATE INDEX IF NOT EXISTS idx_site_leads_created_at ON site_leads(created_at);

CREATE TABLE IF NOT EXISTS webhook_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT,          -- 'crm' | 'calltouch'
    ok INTEGER,
    error TEXT,
    raw_json TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);
"""


@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with get_db() as conn:
        conn.executescript(SCHEMA)


def log_webhook(kind: str, ok: bool, error: str | None, payload: dict):
    with get_db() as conn:
        conn.execute(
            "INSERT INTO webhook_log (kind, ok, error, raw_json) VALUES (?, ?, ?, ?)",
            (kind, 1 if ok else 0, error, json.dumps(payload, ensure_ascii=False)),
        )


def upsert_call(row: dict):
    with get_db() as conn:
        conn.execute(
            """
            INSERT INTO calls (calltouch_id, phone, phone_norm, source, medium, campaign,
                term, content, city, call_phase, status, is_unique, is_target, duration,
                started_at, record_url, raw_json)
            VALUES (:calltouch_id, :phone, :phone_norm, :source, :medium, :campaign,
                :term, :content, :city, :call_phase, :status, :is_unique, :is_target,
                :duration, :started_at, :record_url, :raw_json)
            ON CONFLICT(calltouch_id) DO UPDATE SET
                phone=excluded.phone,
                phone_norm=excluded.phone_norm,
                source=excluded.source,
                medium=excluded.medium,
                campaign=excluded.campaign,
                term=excluded.term,
                content=excluded.content,
                city=excluded.city,
                call_phase=excluded.call_phase,
                status=excluded.status,
                is_unique=excluded.is_unique,
                is_target=excluded.is_target,
                duration=excluded.duration,
                started_at=excluded.started_at,
                record_url=excluded.record_url,
                raw_json=excluded.raw_json
            """,
            row,
        )


def upsert_client(row: dict):
    with get_db() as conn:
        conn.execute(
            """
            INSERT INTO crm_clients (crm_id, phone, phone_norm, name, raw_json, updated_at)
            VALUES (:crm_id, :phone, :phone_norm, :name, :raw_json, datetime('now'))
            ON CONFLICT(crm_id) DO UPDATE SET
                phone=excluded.phone, phone_norm=excluded.phone_norm,
                name=excluded.name, raw_json=excluded.raw_json,
                updated_at=datetime('now')
            """,
            row,
        )


def upsert_visit(row: dict):
    with get_db() as conn:
        conn.execute(
            """
            INSERT INTO crm_visits (crm_id, client_crm_id, resource_id, visit_datetime,
                total_price, is_paid, attendance, deleted, services_json, raw_json, updated_at)
            VALUES (:crm_id, :client_crm_id, :resource_id, :visit_datetime,
                :total_price, :is_paid, :attendance, :deleted, :services_json, :raw_json, datetime('now'))
            ON CONFLICT(crm_id) DO UPDATE SET
                client_crm_id=excluded.client_crm_id,
                resource_id=excluded.resource_id,
                visit_datetime=excluded.visit_datetime,
                total_price=excluded.total_price,
                is_paid=excluded.is_paid,
                attendance=excluded.attendance,
                deleted=excluded.deleted,
                services_json=excluded.services_json,
                raw_json=excluded.raw_json,
                updated_at=datetime('now')
            """,
            row,
        )


def upsert_employee(row: dict):
    with get_db() as conn:
        conn.execute(
            """
            INSERT INTO crm_employees (crm_id, firstname, lastname, patronymic, position,
                is_fired, is_deleted, raw_json, updated_at)
            VALUES (:crm_id, :firstname, :lastname, :patronymic, :position,
                :is_fired, :is_deleted, :raw_json, datetime('now'))
            ON CONFLICT(crm_id) DO UPDATE SET
                firstname=excluded.firstname,
                lastname=excluded.lastname,
                patronymic=excluded.patronymic,
                position=excluded.position,
                is_fired=excluded.is_fired,
                is_deleted=excluded.is_deleted,
                raw_json=excluded.raw_json,
                updated_at=datetime('now')
            """,
            row,
        )


def upsert_dormant_status(row: dict):
    with get_db() as conn:
        conn.execute(
            """
            INSERT INTO dormant_outreach (client_crm_id, status, note, updated_at)
            VALUES (:client_crm_id, :status, :note, datetime('now'))
            ON CONFLICT(client_crm_id) DO UPDATE SET
                status=excluded.status,
                note=excluded.note,
                updated_at=datetime('now')
            """,
            row,
        )


def upsert_site_lead(row: dict):
    """row: tilda_tranid, form_id, page_url, name, phone, phone_norm, message,
    source, medium, campaign, term, content, visitor_id, raw_json"""
    with get_db() as conn:
        conn.execute(
            """
            INSERT INTO site_leads (tilda_tranid, form_id, page_url, name, phone, phone_norm,
                message, source, medium, campaign, term, content, visitor_id, raw_json)
            VALUES (:tilda_tranid, :form_id, :page_url, :name, :phone, :phone_norm,
                :message, :source, :medium, :campaign, :term, :content, :visitor_id, :raw_json)
            ON CONFLICT(tilda_tranid) DO UPDATE SET
                form_id=excluded.form_id,
                page_url=excluded.page_url,
                name=excluded.name,
                phone=excluded.phone,
                phone_norm=excluded.phone_norm,
                message=excluded.message,
                source=excluded.source,
                medium=excluded.medium,
                campaign=excluded.campaign,
                term=excluded.term,
                content=excluded.content,
                visitor_id=excluded.visitor_id,
                raw_json=excluded.raw_json
            """,
            row,
        )


def upsert_ad_spend(row: dict):
    """row: channel, period_date (YYYY-MM-01 для ручного месячного ввода), amount, source ('manual'|'api')"""
    with get_db() as conn:
        conn.execute(
            """
            INSERT INTO ad_spend (channel, period_date, amount, source, updated_at)
            VALUES (:channel, :period_date, :amount, :source, datetime('now'))
            ON CONFLICT(channel, period_date, source) DO UPDATE SET
                amount=excluded.amount,
                updated_at=datetime('now')
            """,
            row,
        )


def upsert_payment(row: dict):
    with get_db() as conn:
        conn.execute(
            """
            INSERT INTO crm_payments (crm_id, client_crm_id, visit_crm_id, amount,
                payment_method, payment_type, payment_date, raw_json, updated_at)
            VALUES (:crm_id, :client_crm_id, :visit_crm_id, :amount,
                :payment_method, :payment_type, :payment_date, :raw_json, datetime('now'))
            ON CONFLICT(crm_id) DO UPDATE SET
                client_crm_id=excluded.client_crm_id,
                visit_crm_id=excluded.visit_crm_id,
                amount=excluded.amount,
                payment_method=excluded.payment_method,
                payment_type=excluded.payment_type,
                payment_date=excluded.payment_date,
                raw_json=excluded.raw_json,
                updated_at=datetime('now')
            """,
            row,
        )
