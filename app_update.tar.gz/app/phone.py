"""Phone number normalization.

Правило: +7 и 8 считаются одним и тем же номером, сравниваем по последним
10 цифрам (без кода страны). Всё, что не цифра, отбрасывается.
"""
import re


def normalize_phone(raw: str | None) -> str | None:
    if not raw:
        return None
    digits = re.sub(r"\D", "", raw)
    if len(digits) < 10:
        return None
    return digits[-10:]
