#!/usr/bin/env python3
"""Достаём embedded OpenAPI-спецификацию из swagger-ui-init.js CRM и печатаем
схему для /api/v2/hook_settings (POST/PATCH/DELETE) — без браузера, чистым
Python (только стандартная библиотека, ничего ставить не нужно)."""
import json
import urllib.request

URL = "https://crm3.sqns.ru/docs/swagger/swagger-ui-init.js"


def extract_json_object(text: str, start_marker: str) -> dict:
    idx = text.index(start_marker)
    brace_start = text.index("{", idx)
    depth = 0
    in_string = False
    escape = False
    for i in range(brace_start, len(text)):
        ch = text[i]
        if in_string:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
        else:
            if ch == '"':
                in_string = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return json.loads(text[brace_start:i + 1])
    raise ValueError("Не нашёл сбалансированную скобку — формат файла отличается от ожидаемого")


def main():
    text = urllib.request.urlopen(URL, timeout=15).read().decode("utf-8", "ignore")
    # swagger-ui-init.js обычно содержит `let spec = {...};` или `var spec = {...};`
    for marker in ('let spec = ', 'var spec = ', 'const spec = ', '"spec": '):
        if marker in text:
            spec = extract_json_object(text, marker)
            break
    else:
        raise SystemExit("Не нашёл spec в файле — пришлите файл целиком, разберём вручную")

    hook = spec.get("paths", {}).get("/api/v2/hook_settings")
    print(json.dumps(hook, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
