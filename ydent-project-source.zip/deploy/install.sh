#!/usr/bin/env bash
# Установочный скрипт "сквозной аналитики".
# Запускать один раз через веб-консоль сервера (или SSH) от root.
set -euo pipefail

DOMAIN="analytics.businessway22.ru"
CERT_EMAIL="010zigzag010@gmail.com"
APP_ROOT=/opt/analytics
SERVICE_NAME=analytics.service
APP_USER=analytics
DASH_USER=nikita

echo ">>> [1/9] Устанавливаю системные пакеты..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y python3 python3-venv python3-pip nginx certbot python3-certbot-nginx apache2-utils openssl

echo ">>> [2/9] Создаю системного пользователя..."
id -u "$APP_USER" &>/dev/null || useradd --system --home "$APP_ROOT" --shell /usr/sbin/nologin "$APP_USER"
mkdir -p "$APP_ROOT"

echo ">>> [3/9] Разворачиваю код приложения..."
base64 -d <<'APP_TARBALL_B64' | tar xz -C "$APP_ROOT"
H4sIAAAAAAAAA+w87XIbR3L6jaeYW1WlFr7FEuCXJDiIT5boiDma4on0XV3RLNRyd0CsuNgFdxek
aIZVlnQ+X2KXXU65kl+pfDwBJYsnWh/0K4CvkCdJd8/MfoOSfZJcl2gpkdiZnp6e7p6e7p4ZWMPh
1IXX/DThuTQ3R3/hKf6lz6256dnW9Oxc69LMhWarOTPbvMDmXjdh+Iyi2AoZuxAGQXwe3Ivq/0of
C+Q/sFzfHO6/tj5QwPOzsxPkPzPXbM6m8p+fB/m35menL7Dma6Mo8/w/l7+mabXxf42fjB+OT8eP
x8/HR2dfs/ERfhg/HZ+c3RufQOVRm41/OPsU3r8ZP2MAezx+cPbZ2X2oOh0/ZNdufch0OxzMmNGO
H5nhqM7GJ+ya5XlxMLL7Rg1gPyWkx/D/ZHwMKNjqb5bcmBvMc3d5Y/wIOv7T+MH4FAAfMR3JgU+n
AA69s1+y8Z/P7kMBkcWA0IeyDrqvm7Xa+N+g4gcAuTt+0majXdcOQp+hYrdBw1mj0Q+imLWmL5lN
+GlBwTAIY3YZ9K+GLHAH9G5F+77tBur1dhT46nMQqU/RaHMYBjaPkhLQoJ7rcfUKCHphMGCOFfPY
HXAmy9W7wfC3w73YEoBDK+577qaCW4HXmqjpWaCeQ1fVfACvV1cWDXaL74x4FBvsxtraysIdmw9j
N/DhlVsOD3NtzZBHw8CPeKSw3Fj7cOmWLDTYahxya+D6W2nRigeMW+N3YlWURxjzwdCzYmiiMP6D
69+2ptdEOY/y4PA7dm1kUELBKhV9gEVyoE4yetd3466zabAtLv56wVZ3j2/2g2DbYKNhxMO4a4Nu
pS+ey/04ed11IzeWjO0HfsJ+PwgHlud+wrtUXKu9f3V1oXt98RbrEMv1bheJ7Hbr5tAKAWMtVgMC
iMIQdccNuR0H4X4nikM9QTXFtKSVVq/XahdB1xoMptjx+Ako8PHZvbMvcHbAzDoF/YUJge8PoOJT
MblOxo8ZVsH7/fGfxYyBOamD0h/RNPkKUNyFEtcHznqeGfVxOk3x2J6yfMvbB85GJvd369hzDeZm
98bNm7/urt389cIyDCSgSjcMfBM4rGt5AM1gmt23/C0+4A2Y0lq9du3q0tLazY+u3XgBngqwPLYY
kF1fWFm6+fuJSLLVucYOH3rBPiC4urIiZVZsK2ugWVYiIIPVhVu/Xby20F2++uFCRbtsNfaZMhHU
CSwJh15raEU6av7pdXw3B8HIh/ZTQsE1I6vW5+iHBK/XDeZbA95JCmo1qft6ojdLZBxPQT+eo6kD
k6z04exzVBl4fcxWgUweNlZBZdnCLvyOSPJdMFSRHbqbPIzaLOLxujRv5m9GfMQ3YDxQiH3VHN5j
XT+I3d6+Xm/XGDy9IGQ7oGNgn6NYz+KSAPjE4X76gs+OORzFgGnPcoEzIe+B8enDyFQ9J1PFcoR8
MPK8PJahBba1VvsVMplENMVpWICIWjKkN4q4Hgoz2Fb2UJKWAm1xX8/Qu9POdw0syL3rA+tOBBai
02qmNGfHblqOo+/UJzNg3+WewzSit8363POCj30w/Fab2YHvg0pw52P/Y1/Ltdrrg86wtXDE89jw
cXvMQnYyOVjTjbqOGyXYsuPLPptg1rdLNSWC1TOItpAb1JPiCb50QRH0HRJDXSxcwSjutObqlVjE
8Htq/FIBFAcOoJPD8ujxKSjGmuhnIQyDsJpeyeg22+Z8aKETkUfcc2Eae4XB5kSJTLRCEicBhTwe
gdNQWg91UiKDwZLtWt14fwhTNobFUShlIyJ4nL1izr6qB7CN/yV1tKqcrP/59FtGNuA7MAl3YVlA
Dw2XjWO5RGSMxMrN1TU2Bevx1O70FK6lXZj8uIZH2NF/g7v1ufT+zv5Avtcz8LuG1r4XWA4Dx+qe
gDj7OkE+/mF8isBHsFbdO7uP79jZw7Mvzj4TZIGvdvYlLnBQgOWwhJ2S5/aQ6eCpPTOZXNe7sMaD
G/dq+UfmYwh+H9gP7CSaAu5NHcTBNvcPc6YEypWHoVN1G5cQg00wLzAjCYr9osPyq2eqbaHlRjzv
nemzzVkxa3KTUPG4U5jm6HzqAl5OjgRTVeMDrRtae93NwNmHSaHncWGpXq+bDrcDh+vaKO41LuNa
526BVwQL3GGtTFgX1l4H/CHkjuxHl3/TyZ9xznQN/QWDzJjBlsHFMlgOvjgMmO2Mtxm7CK7ZDpiH
95cWms0WaTWGCkwEAKhxhaCDnKQGOkTgKUHYcALr4xPwqVBnQQt/gILnMCeOzqPyA8tDVxcXZ14v
EJqxBge0Oo8i4KkGWLa4091z436Xo2VCDooPbYlI8jFZS2sTUAXb2qFadyezuc0c11ZaB2HK+D9h
fI9hsCcUTsFEZDCNwDuAGXaP4ipQR5ON/wPKHsEPTsc/Q/lDCYyxFHIP/YhT6VvC7Bx/j0UnEHcd
CMOttU3T0NBma+0D0zQPDw0iATqh9ic41wEFRlvQ7ntGNPwzubj3BK7HFDseTQHAU6QM+rmH4npO
cdqnINRnYFS+EiYM0T5jNKbHqSt8rpGBHr8bnwqqMqZGFOcj1CNBMBpH0isi9jNi0QlozClaTjGk
U4I6ogE8K2iTiWEidodsgfkmRST8E2JVUdv92I33u30XvLIO03Pwgst1Bj5WrhwXF1GsaXXTC/Z4
qMvVCVZ9CmwAl0YfNHTOsp1AqwNNxEKLDqomLL3BKLS5eFPRp3bI/oYGYW7z/UiqKGAXLRG9+FSF
Xz/QKHZCfD03jGJ0YIsIGegzSwmByY1BHUGosfTS4SDWDLAEFDjiAAKclRBd8ARDap9Eo66UBxFA
TBTl11EkxMqDw6RJNkLUc57BQcnJQDvRdR2YrSlqeK0bFZCCkooGycCqmin5FBtl5FbVjKjvJuLM
tkwKq9oRN7tDYme2UYbLVc1AUkOLKGyh4DLMiFawvM44WFLWrGhqxTEH188vdJgprurQ4R4Hv7bc
oao4p0cZsUVdXD0BA/4xndFgCAFZgkcBCfVY3zBAzaNRyLtWZLtuh1aGSnnB+lqN9yUwpEqYrjHg
eP07mqeHaOqkKQWb+hQs4+dge74XNukRGL6v0cUTdpxyBCxvVw0GVvEulqApfq6SdX8CM/q0bO6f
JQQAezOzKNXxQjhGWZROGVTYgnwkkMvJ6CUmlucZsTaZOpXklGVBjUT3bUHfeTBdTP0AYCEDpNPv
SdjJtFUQROWkOaWq1CROQlqtQhlEL6mLh7mSoteStbLSrOOSIvilLGnGiZTynSzYc4T6FxnOF0jw
p0lPSa5KZC8pq1c/1bOCEbHBby1vxCnA1Xsa2AHwd+9jfk84VmdfMumOHKMjJ3LxUEh+3g9gJcBG
/BP6O9J7AcevTUbh7CuwHSedA0rbZFbl+uEbCFFVxl+5dSJk/AIT/uhqoQE6EkYNE1lg355TjvM5
+nh30WkjswXjFNHrXSY58BBKvmKUAcUCdDyPDOz9CXy+J7cKjjP9Ux/o7T6G3hP3N/EBj2S0fDr+
HnOwSB3aUQik0f87+yO8n0g/mvxHakhbF8+ECca+n5FTelcWSveTYThCmIE0pv/9whpaawy+DQax
WLiPrxiO1ROvFN3R+8KuPyczjrsaiA7+Qj9E0V01biL7CKj9RhhziqwBAOk7okFgdJ1w+5QGTxnD
Vx1eU+xCs0iXgYrB3kFdyyQQt9HYYFk7u+RQqUMunrO+vaEcRF2EjFpx+ZHhE4Jmw6llyuGLKN8a
ut0wGMU8DfWVKiQBPyZw4n7gRJ11DcSCLiyKRdvIZQJUs5+cD6jIgr9EVoAghlZoDXCvAZmpcpsm
aU1X1NVVf6pSDIl1OnIw56RmUenOSzJkBAQOJu4tgIOmYysjG4ZmH0GUORqi30mgpUxvRc6ikjqp
MYMShViol5ON+a6JYQhZz0OeT4TAg6nmEklqSZQKLnoz5IK0PBpscgr+5fqUvIsFslCfWUfDYA9T
NTkqtFTnaNHEREKxWwQRURx+Qjj4OPJdYBEGCTJgzK9C5y2uP35h1URIAtBF2kbxoCsrjQSs2Bpz
p6PBhNay0kjAiq1tawAhyJY/oX1SbWRAizhiHk7qn6oMCVLqO/BjSolUdy1rjRSwhAAC6IrWVFwe
KEh32LeiKkZjpagzcpAlSaksUxWCVVFpJGDF1uAyCsVS8VeVPgoIXG5TRaQ92VLyggy71iL2hiMi
fZ8ir6oQDjuPrRD8s/M6FxCqc/H2Kjp3RqGFRgL6dsHLLXfrbV9XIEYGnHpt1ieTe147pNaNHHfL
jfUJdOEBFQh7u1aVEuK4r4MJVBkexRb8nLi8lBMwR7HtB3s69hegrbRwRyffVcjtIHS6o9Cr6EpU
fhR6mpGDLCGp9J0VmnO959RzBmaiWwAGcz1vIDcKzkEZACxsT/MD12kclMeOb8DQwVAHh7gU3wAe
HTBOSm+rbkpJ7nRtfrkc94vxl9LTaRc07DeRnX7lscK34JNS4hhd/wdi73r1RpscotWGjBeeUDoj
cewpSzx+dPYNuLjfSUf+mmeNHJ7486XtcZEfwQTv0evcVAIrwUPf8qaSwwmpIymKShvUBrvTFVXd
1LEEhRXndnRoaY28uANWIfUt8y3QycyekniRczkjpFzp/YltobL3gzqkDjWZwZD7On4KNm933MB8
fz/m0eJN4e6BUx04vKOF7a1PwNyAsse9/ASNtt0hbU9RLOpsSuOEHxt7lpd9jfoDLZ/YiKweB/cA
3Sn0i9dL7tuAwowBGvq4h4G9BK7wGIGTAxMDfhVvEGWUZzbNJEtNB4EEHB0DiiMCwVpRapI5jpBF
oAKF5NfGi51cIJPfiUPLxrM7ujyzgrEJ0d3JjthgwHZQsY7YX6h0bdf2h3zCLvlFRrkBiA1pi2dl
H0IFX807kVlM9ohw90x2xvS/ZTNmq2XOig1m2swRU+uJyj/KfaRjike/LOdPsGvcOKHdqSdqcEwc
aMI9u3tnfwC8EOTKMJyiVKqgw3DAOmsXWlgeHZXC7Z/vyW5AaPvN+Nu/hKk5M52bLIWZ9FPMefUU
bIIgtU0LIt7Q7ru70P6AUzYGm6SnCc1w5OvrWjRyAvLP9qOYD+xYLrekdnjGKHNaacNgdp/b23Id
nWTOhfngDhn1zKGaxH71ueXF/Zz9EkXqbEn1GoHOTbIDMdnHeE1LSea86OvIbMDcjyAg4qEbOOVz
RqzxdyweDT2+TokB+CX9kjhwrH2RSy1whALVutpC5F06oNhhVWG+zFACgHDhdIG1kZ4b1eE96sw0
6zlOp8jj4FzUcSAQE94SBpVwUVQaCqfase6NfJ97lK/WEyiZI5Gg8k2Eg2KV+0dyl6RG0RIjTnjq
tG7geaZ0BmJ0I9qS3Q/XVWC5QQY/RFONLWDacxvzPnkXdHVhaeHaGru+uLq2uAwfRGP2wa2bH1KK
J2K/u7Fwa0GVL66y5ZtrbPmjpSV289b1hVvs/d/LutRHrJs9Htt9NDD1jVpSvIM7plr+QJPs3nUM
lgbaihkGS6KcXKOUuFyxJHS0iS5cGgoYLaMFMcf7C2u/W1hYZu+xq8vX2XtJyyxF0BUxsSzPdLnC
2EWIKtf5DvsljI5wS1Z12Hv5sSJ2E2wK9x1dwKTrlGB1Jy+pHYPaZNmZclPsUap2Hnge9DmzEyFi
TWIrghzY69lkhlAPm9SDkOAOVx4i9TAyoSOiikYDvVXdPo1LNzLEyhglR1Jl6rJijyQzULCfmbd8
PI2VzXyUS/CZ14rdCw+8SdWSdotpNxXf5E5uk5aUXe5TmF+5kSomH9RmpmJxmyNNl3mWzfuB5wg/
TTM083bg+rr2nkYM7SJDc3zKKAnlzEpqkuuqp2a02FrKTis5b6BcIRIzJgOxuMz0gyyJh3UtPxTa
LMnTZ1RO/DRwQxYrFRUdF4cEhNK8A/2RO2JZ7RRtMoZECgpaNFO+grhyBVJoWGY2s4qYdlncu50o
j7RJ3rMkQs6Xh5CJlkgle/6B7BsSbrDMiYNUTAJ9CR0+QnI5bFJ4/cM6WSF5BADHD92X9TYdU76u
UoYZrndTLTzYXS8c6BBi20WeCeLzQQqO9ce1R4HtricnKzYOq0iSylUgsF7qWsJlqagXjJDSGbRw
0G/2IMgGJa9eRGDG6FWatHPMWR6uYNqQ8EnTTuB9WbuX2Dz6W6hLbaD8VMyGC6tISltMiCkjGQYj
Hx1BejfYdHV+fKLBLLjeGm4miePFIDQrijrZSzlZR1z6WkNra+Jx9/LCjjsXVQ6sUIxkKZ/sIKo0
PmoHbbTJfizaE6ly/5K+lZ+T8yWTOzGmukGTnK5OfRaB1+zHAy8ztQ+KEiGaUSIqpSJPKjKxPa8l
JMnARJBXyPUKWhUEUp3ucEj+UHY2I0HxsZ4XpNDMl5Ymgb9SYb7Aka50wfK8qHZebfMdg5Wtvqxt
lZdd20vst5lZfKHr7OvS4oeL0DxvnNnVVQbhB8SyzgSXmNmvwCnGJ3Xvk1bs+sLqtRyQIHK62Swy
Kq9FFcp/ntvwY6YCDbo0EyqVX9lG5T1Wq3+FyicK/XPfQX37/HwP3v9GXXJDPsBpbMZ3Xvk15/Pv
fzebremWuv89Oz/TutBszcy3Zt/e/34Tj7yk2+k0zVZrDmIKeXd6Hc9/OFbobGDVTNOcr92mG7Cd
zozZMmdrQ0onNwYjL3YxT45gTfPKW2Py1/Xg/Bf3T1/f14D8iO//mJ1vTtP3P0zPvP3+jzfxZOSP
Tu3t6DX08QL735q+NFuQP5TMvbX/b+KZmmLjf6WrBae0M1faSj9uq+0+Olsqz6WqGwbyGpW49ZUc
BDZw+09c04LfeCT26dk35ctq2SvsqwtGDWk5YekZV8D7R3X6Vpxzhn6f0V0IQYJqDsDfya9LOEqu
p+p0mPq5On8MFFA76NgQhBzTBbDMd5I8lWeG1U2y47pZ0yEotWnnD6IrDEXdHtN/sef6TrBn0mX7
VRHtSvf+XQDZBYWi5LTP91gGJnOPHcE43San+iU3irnPw/TKvMGKHTOG/EFyHwg5AFvpy1rE90Ko
fdwjGN3nJKoH+MUSeI+SLrnR6Qk6Qi6PTeAVE+I1XdfNSObsazxULG6e4EW9R9S57XErlNeydTn+
bleSi+UhDQoD0oo68V0Dqnl5aEkzL7DpdJQZcroJKZEeGvhdLfRyCL8P61jxc8+d/wtPxv5H8b7H
TTt65UvA+fa/1ZzOrP9zsBaA/z97af6t/X8TTxvHRZPQDrwgbER2HwLBNvPcrX6M063RiEZhz7J5
o9UWM/Viz4afTVGJqax2JidysXcFfi6JSvyWhMYwdAdWuI9AF5ub+JOpjLgdYJgB1RfnpudaszxT
ORjF3BHIL16+cvnS5Zao3Apdx3P9pN+LvMWbzhVRuWlFPFdpz9jTm5KgzSB0eJjSG25tWnqrZYh/
EAIJEwNj5qHLo2TI7OK0demyM/8um3qHbXojzt6ZknA7jem5ZoLx4uX5zXneezepnMlWzs1ducwv
pZWz2UrZQ1I5l61s2XO2JRm3FQROjuVN25pp2mAVa7+i76hg+hBsLw+jRl6mwOdtYXBJ6u29Pg+5
3vaDWMfNYasRI1xHI9lrG3VlnMtYhFGuUI2WBT9XVHVJOZoO/qjqknr06MlVZxUkleQLVKRSSaZt
+LFUdUlNZi7Dz1xSXaUo03Nzhvqf6EqltswAKXwurS4oSevybO9KrjqnJtNz89ZmL1udU5Qy8pyq
zDvWJW4nbJikLLglcVirvcMO2GZwpxG5n7j+VpuJgcP477wLAHRqEJUARLTl+m3WxIa9wI8bPWvg
eiAVcUypMXIN1oDFxOMNUWIwbZVvBZx9tIjfyGT5EbHpf9s71t42juN3/ortFQbJlqT4kGT7TKlV
LCYR6ldtOU2QGsZJPFkXUSRLUpZdx0DjFmmAFHVrBGiRog2SAP3SL64RNwn8CJBfIP+F/JLOY3dv
9u4omn4oKCrCsMi93dl57ezs3u4MkbUWrG9doRcqPjpLBdYUYifpmimVCoKzfi4AbHWNqAvaG40Q
y1xl1OuvgRVHTNvRsN8JALGNTngNIQagzt1yBCgNfbUe4pknLH4HDH+0cb2sj+0DIX3U5LVwtBuG
5Mb1wTsjntRm+9dUHf7Lxt0OAiLAMnA0wjMxNWg67HWitq7Mj4mYytoAjxbeYH7uhjjqfDVfrSJN
hqRucFUFQgTlTrgBtepVxoY4hFE9+Ew53uXohtl8tCOpaGWIoY6YPEGvRd0Q7BJUtwSNAP0hR0oj
ciTGlQAcvKthLK4sgbqgy05NM6SKLGAtJYBnpUICAa5cK+9G7dEm0FE9VuUirasq2Bn1uD2fbRxm
a8iVoA+t6/20uoRdMlaa9ZYFVYdhWkFq89MoyD6aYVk+CNrRzhAJQ8g3Yyo6wVrYAV64lND/ZY47
RroADN3Z7p5g+ohbUupIb4Z0yKIS1213Ube/Myop+xssJ3RBvESAYixajgAv1DHsIEHKfFyWwQFt
k4sT2TjBTFhM13ZAYt19MT2KopudhKoZVhlYxYqqkdrdBO2BXzuDIf7s9yK2OaiHW/2ojJfAhOxw
ojpB/5fNq6EyS26Ir3n6YTAqoCKXNyIQwnbUBZUv1GZBJ0qqtjEoFk8IBU6pKgnhJnc8wiBjNyby
dpKCZqtn9nCQPVeM2k6hhQly5pPUVK7iLWoXZn3eqrpjVKkE+ogC+NvdgVVptA7iGfQwOiQMmKCD
pcOsDirbIP/rvh9sgCTJqOlJw1Pf3XrknUiZ030HFugnvemecgTPZ8jXiJcBTqVatfkqimljoI7j
l6NkO7MmS6lebld4Fv5KWKZD9a5YG9k8EHOQAAWzRhkPb2+hL5JSTePIpRWPGLKpRcxS710NBxud
3q6vNqN2G+bxRDdgGJDtplGtWj0yZuBnDHTyw4pjmOAooqN3RDkxFsYzLavGqOIoWNvpAJJWC9O9
9NHuTjOAMjoHBYSe0BQoO3MKNgCsTtAfhqR99C2TG89rMDJFNdosqRG6RBJt9HiEwT6GWltNzmYN
YcHH+V5Ck7CrTOfE8M0R4xz7ZKOB3wmGo/L6ZtRpM56JHmmaQMmtBe0roRyKURd7Lq91eutbgpj6
mHny+PHjmfO1AV3pJQcLL2Xrpdp8owR/YH1ST86TuBYoChjdXhaMOqyE547jPxfGD9vVxlpjjdoP
2UCBiRx1kkN/Ltv6Gq8M3TZwzViCNw/38L7nD+7/2RMpL+kV4FTv/+pz+P6n0Th6+P7vID6u/MUJ
vBfYx4T3f3PVeiOWfw3lPztXaxzu/x7E58YRBdMerHOHysP1F585U0du5uAJzVaKjfyRm3t3nJj8
dDfwT8lEAQiv2+aGEohZwENZrkmBPvigpKeXap6OzrLg4S2LRVhONGm5sLj3qWrSAlRx5F262K4D
Z9MpN0We14J344a4V3XzprfYnGEIAtYne4/HQxv1UrBGvXGQPjY5EmiframXxDqeNx8kXdRvtpo9
vjqoYXuLe3fw9Si/ViUYTz5sznAl0wb4hkeyhyZYV8VchjoSnxVPwAWch4itgi95xids5+lmD8aH
0YdaKcJAPg8VF3WDjK5Bgti77qs5w9CIfMEJvbhmRg531rYjEJyJmYRvJfFtY3OGqy3mmjMo9kUQ
fzu6aqSv18Ms8EQ5rr+A96KU+oY+/iLTP1D4PIqB/Lg5A5WdFsQbb5HlGVTk9SKknKrT/1P1/08K
yHVfhzp2s1FMxkHeOnoOJP6GEVs1AzD818SO+crKc/T4EQXbpSCDX3CQVRvndWLn5lLDc3T/D4od
cJcsDSAxsUu6HPEc/d0B6f6GQjFSDLAvOXQZhSjDd+Nj+le0VUBYeEcq1Q3vXX23knDS9weKSbz0
H2dsOE424iPNr6845LeO2w22V333/p1YFx+bggcU2Je+Wnnxz8eWn3cNFqJ3dgVoYIJFGIYjRSvQ
+Bp+wRPj8CuvlBph+iw01PucMYzjgaP1+zLdWN4OiVuToj/5UBXIWH5N4fAoaQapfdE0JvWOW+2j
rKaF1sm4TULDTD1UJKp0iU2i5gdOlyZqojQsJmapLFuEJQ+Z3poFgRYW54sSG3CKSMAcphppWVhD
6T6M92BI6WgzxmhXqnJyxyWepLIr4X6Jp+hkwIKndwugkwKjPMM8+BFuIBTVu/qOTA21+4i3KFHI
xkbsnBDuDHUs8nYLhCo/BQ7xoDdfnMnNDrq+oXDCfoDYayDGgcLY41IyMP5dmBnwBM5D1iU65/Qe
RyjXIUu+0bH8fksaZ4OWEKyMSWVGqC9afPK97mnr9IhDpDyWuHCsSOckFQbPptNANuZiBTjQB/oT
Ptv37ZIefg7w467/4msnL7KPCeu/Bi723fX/bKNRO1z/HcRnmvWfmO7/X1d/z7zmoR13AjHaBEdF
T26jgZ1/R5uLFNSEkibco3OtD5/cbs5AuazyGS89MEfL3qPU07+6LmHqOa5aH8KUo0PCpp5/xMKs
8AHeDACfUkChW5hoL/Xs77F3ZpckiSqUpY8c1z/Ez+DbgCdpy5rmCE+e8GPtKomYDGZdKrnXRpdg
/W0ZLO8SeRKjdroSR8akq88eKLI3tqINOjKxpo07+RR1bQRAffl6bO8cbGdfiHY3ANjEsSr0RUrv
ktwrwC2KftA1w45fT/TA/cND0rDAh2cOKPJVJ7Xv9qA9hiy+lQWh2wZ8LIjJeIuIgoh6M1Cbg3CD
RuP62/n4af4S7XLwMnrBu7zWCbpAiI6b/4EZgsFiTAbwbj+MjAKmKEcNA2TxDQjSt+Ad8yZ6iunt
ieTC0Qan5njPtyqEiYuE2ICBBzwY4AsbkWdyWM2b41Gvr9/AsQv7MQXjNpt63/4rYxh/+4DNvQ73
pXhVJRIQYKRuzg3DiVMeke97n1armLkHg46hdbxfUXuf6fjV71E6RMzcQ/G20W3+Si2tlMF6vU8O
sV50O6xEt/k2WMfbIgUV1PkPQD70ZZ/p4/p/1gN4oX1Muv/TqMf+39wc5n+erR3m/z2YT/MH7d46
ujMKxQ5GBv8oMKlXFrzBjqfS54KxDk3TTfDZArW+iaEJwBBzTjFTzE7V1SjcxdM1nvEA9SbCQjvE
DCx8cq9EKV+joFMewvweLtQQCDmdi2kfdILLCTaSGuaanai7pQZhB7cNwFQON0PwLPWUkrrxgD3O
aKrozKvZ0Yt+XUbBG6LDgXnChx1T+9Z0pBOmgMkZleO9iW5g9jrMlDfjGXi4l89HKfMy7DtMgxWK
k7iwoPIzebGrn9wnxIkwAZwDBkzVAzVJdCNWA7qT5gyRwpwMB6gKQWR9BhMfW2/DJBcGCcPdpKzk
AALTNfZHajhYj+XGNxXRM+en2KeZI1mNv+9h9T/zQfvfXnuZ2d8n3v+pz9fnrf2fncX7/7VG9fD9
74F8MIgXJWIHj7I3CMCr7wTXw0EF9zbpeqSNvkqRV0s2fuw9cl4/oAuJX2N+68/xOTuKX+jrmnft
YvQxFj54cjtH90Vtmr5v9I1Szgt6l1KwPEBziXliKKHVXbrt+FC9ce5CRSRql5nZh7/qAP4NzvhN
BuXaSGRT1yXbQReoG+yTcH35lcvnllZfH5cNHFM3mxjGudyFk6+3Ti/p2I8nz7eWVltqdemVUy21
8ioFk2y9uXJh9YJesXJkF4pmttp6rXVenTu/cnrp/FvqZ6231NLF1bMrZwDG6daZVX4XIQOaq9XW
m6vq4pmVn19s8VNOToHF4jeH14kL9fveuIBzK4gCs2QVRZgBQdbQ1lmURKPrDgiThUD2TMtWUWBT
ChjybTEv4txiszp2S0W4nhhwvCiUhTr8vERzEAaisVpuvbp08dQqB/DBmKqFfLe3my8Wc8UTRpgr
Z5ZbbyaEGbWvXdYRnGKWnz3DQi7EZU8LRRBlocRlAGVfzRKxl6bWLxNbj2tPrVz0kmlflnNilhfE
cqYyyfSYfpf1k5imQ9y9QJ4lIxYKvRU5Ht0HbhZHOQZF0EQg5JQdLPQ+24ERJ1IU7U2IRIOo4byO
8ulkSDw4GTLTTTY6LT4uLDjse2pQlnUuMJevE9QhaF8eYuTa6ZVhM6AT/MQXEzu4ZPa0ymWVvw4L
gfDaZT7Mn1fvqnz9SjSkL/rRdtCn35VKhUcaRXcj1DPgAsy34FM+fbq8vIwioAxitBVjyqs1Pcsq
82bQzLMPae/mtiy6R+77FzpJcrDd2wG5oL7F3SbnEasAeZhMd4JOvkSU6h9IWdCP8tOpDnfCg6mg
uVqSrIjDCU6QpUglPrU4t6Iuz7NWhCxE0Cuiy87HTF1vyx2HlGXjBU5B6FPkcj9NeC4YP9AE+vPN
/NzFyArsAOEluS4oW0E7MkVbpzLo7V7egFVeb3Bd1D/f242rmNiA3rnzS6+BZ/MOcL0LhojyO/xi
6ZSXkSfiehR22tTcFhGs9d72dmSiiW9EAKYjWnGVTm+I4dA5ojhuAAi6JsU0FPjyArDA7pgBJ7Oq
oGh1MPLeFt5v7YF+kcBkVHKbu9lJuT0FHomYiitnLrTOr6KWnHUVE9FBTDQOJasrRfXG0qmLrQuq
8JOS0v+SYYp1a8qMBDqoswUZSE6yHSImM9uODFGo+ZVIf/OCeJCIKylZor1i6ebqmM7ZEdPZdy1Z
lzUd+Bc915JxWEvkp5aEe1rSXmkpdkZFHPaSdTrTgEV0SeFvCrk5LYwMfZc0X9PmS+J8Q51vyPPH
0+czgb6l0GcSfUmjb4j0BZV+TGYaqqWb2lpCfUmpn00qTLsnz5559dTKyVVHkEW1fFZdPLeMdvpC
azXVZ4zwQnhtvbPTDtsVQUSWAICmuK6mMVXPkBLXHC/UmLy4tiA5XV9zQNTWJUmVd9vCYBo/2jiZ
7sGMN7lWcGKou+ONz6MZ2kpiGh+n5hpWtoIzOD+Gl5rsJFBHodgXnKBK1FkskxRBiUeMVgoKbVXb
mi4L0gJPt4+ZtJCg79mVgzPUH5humCWREWcioLtYxJQSC5cMSxyvX0Qo+HipUjIrlJK7Fnk2vUtg
6juo+pNw9R1kfYutL9H1Lb5+AuGXp9kOWcJOOtRmmDVLvLRrMUdSLVwGxY2mEHLcSDIz1ULzNq5t
mJ2qGfM+rizkkTb8LB5h97W80lOJFJ+YURypTmH8X5otOLj9X9z/J+P4El8BTHj/Wz0qzv/N1o7i
/b9q4/D974F8QBPP0Y4fJzG2uYA5CF8ut/cJnde4R1sNj33146N4TuMYni3+PZ+mf/JHcxiDt/bp
BMhXivby4RslfHMOhODhMg30EUWe1EnlvtFvBGjf/76BlatVFR0Q+R21eagK5g2EzvAojjk/+bBY
UXi76smfTRREPvMcAyhRkrm9f3NW9Tg5PFJQyYk3DINQz8jJ7Mgw+J18VpgKLP5pszZS9lKoake1
TFtOZgtzvg4pC0NluLNWGHi/XMaUah5NhDbTN6bI4KpF1VS16niAJm0XVX67DFUvHb4HPfwcfg4/
4z//Bajk2scAoAAA
APP_TARBALL_B64

echo ">>> [4/9] Ставлю Python-зависимости в venv..."
python3 -m venv "$APP_ROOT/venv"
"$APP_ROOT/venv/bin/pip" install -q --upgrade pip
"$APP_ROOT/venv/bin/pip" install -q -r "$APP_ROOT/app/requirements.txt"

echo ">>> [5/9] Генерирую секреты..."
CRM_TOKEN=$(openssl rand -hex 20)
CT_TOKEN=$(openssl rand -hex 20)
DEPLOY_TOKEN=$(openssl rand -hex 24)
cat > /etc/analytics.env << EOF
CRM_HOOK_TOKEN=$CRM_TOKEN
CALLTOUCH_HOOK_TOKEN=$CT_TOKEN
DEPLOY_TOKEN=$DEPLOY_TOKEN
APP_DIR=$APP_ROOT/app
SERVICE_NAME=$SERVICE_NAME
EOF
chmod 600 /etc/analytics.env
chown "$APP_USER":"$APP_USER" /etc/analytics.env

echo ">>> [6/9] Настраиваю systemd-сервис..."
cat > /etc/systemd/system/$SERVICE_NAME << EOF
[Unit]
Description=Skvoznaya analytics dashboard
After=network.target

[Service]
User=$APP_USER
WorkingDirectory=$APP_ROOT/app
EnvironmentFile=/etc/analytics.env
ExecStart=$APP_ROOT/venv/bin/uvicorn main:app --host 127.0.0.1 --port 8000
Restart=on-failure
RestartSec=2

[Install]
WantedBy=multi-user.target
EOF

chown -R "$APP_USER":"$APP_USER" "$APP_ROOT"

echo ">>> [7/9] Разрешаю сервису перезапускать себя без пароля (для деплоя без SSH)..."
echo "$APP_USER ALL=(root) NOPASSWD: /bin/systemctl restart $SERVICE_NAME" > /etc/sudoers.d/analytics-deploy
chmod 440 /etc/sudoers.d/analytics-deploy

systemctl daemon-reload
systemctl enable --now $SERVICE_NAME

echo ">>> [8/9] Настраиваю nginx и логин для дашборда..."
DASH_PASS=$(openssl rand -base64 12 | tr -d '=+/' | cut -c1-16)
htpasswd -bc /etc/nginx/analytics.htpasswd "$DASH_USER" "$DASH_PASS"

cat > /etc/nginx/sites-available/analytics << EOF
server {
    listen 80;
    server_name $DOMAIN;

    location ~ ^/(hooks|internal)/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }

    location /events {
        auth_basic "Analytics";
        auth_basic_user_file /etc/nginx/analytics.htpasswd;
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host \$host;
        proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_buffering off;
        proxy_read_timeout 3600s;
    }

    location / {
        auth_basic "Analytics";
        auth_basic_user_file /etc/nginx/analytics.htpasswd;
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }
}
EOF
ln -sf /etc/nginx/sites-available/analytics /etc/nginx/sites-enabled/analytics
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx

echo ">>> [9/9] Выпускаю HTTPS-сертификат (нужно, чтобы DNS уже указывал на этот сервер)..."
if certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos -m "$CERT_EMAIL" --redirect; then
  CERT_OK=1
else
  CERT_OK=0
  echo "!!! Не получилось (обычно значит, что DNS ещё не обновился). Повторите позже вручную:"
  echo "    certbot --nginx -d $DOMAIN --non-interactive --agree-tos -m $CERT_EMAIL --redirect"
fi

echo "=================================================================="
echo "ГОТОВО"
echo "------------------------------------------------------------------"
echo "Дашборд:            https://$DOMAIN/  (пока не выпущен сертификат — http://$DOMAIN/)"
echo "Логин / пароль:      $DASH_USER / $DASH_PASS"
echo ""
echo "Webhook URL для CRM (hook_settings):"
echo "  https://$DOMAIN/hooks/crm/$CRM_TOKEN"
echo ""
echo "Webhook URL для Calltouch:"
echo "  https://$DOMAIN/hooks/calltouch/$CT_TOKEN"
echo ""
echo "DEPLOY_TOKEN (пришлите его Клоду в чат, он нужен для будущих обновлений):"
echo "  $DEPLOY_TOKEN"
echo "=================================================================="
