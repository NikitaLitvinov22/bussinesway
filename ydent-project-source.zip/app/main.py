"""
Командный пункт Ydent: приём вебхуков CRM (crm3.sqns.ru) и Calltouch,
хранение в SQLite, live-дашборд (воронка + журнал звонков).

Запуск: uvicorn main:app --host 127.0.0.1 --port 8000
"""
import asyncio
import hashlib
import hmac
import json
import os
import secrets
import subprocess
import tarfile
import io
import time
import urllib.request
import urllib.parse
import urllib.error
import zlib
from datetime import datetime, timedelta
from pathlib import Path

from fastapi import FastAPI, Request, HTTPException, Header
from fastapi.responses import HTMLResponse, StreamingResponse, PlainTextResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles

from db import init_db, get_db, log_webhook, upsert_call, upsert_client, upsert_visit, upsert_payment, upsert_ad_spend, upsert_employee, upsert_dormant_status, upsert_site_lead
from phone import normalize_phone


def _to_float(val) -> float | None:
    if val is None or val == "":
        return None
    try:
        return float(str(val).replace(",", ".").replace(" ", ""))
    except ValueError:
        return None

BASE_DIR = Path(__file__).parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
# Версия статики по mtime style.css — автоматически сбрасывает кэш браузера
# на каждом деплое (иначе после смены дизайна браузер может ещё долго
# показывать старый закэшированный style.css/app.js по тому же URL).
templates.env.globals["asset_v"] = str(int((BASE_DIR / "static" / "style.css").stat().st_mtime))

# --- Секреты и токены берём из окружения (задаются install.sh в /etc/analytics.env) ---
CRM_HOOK_TOKEN = os.environ.get("CRM_HOOK_TOKEN", "changeme-crm")
CALLTOUCH_HOOK_TOKEN = os.environ.get("CALLTOUCH_HOOK_TOKEN", "changeme-ct")
# Вебхук с лид-форм сайта (Tilda) — отдельный от Calltouch, потому что это
# другой источник заявок (форма на сайте, а не звонок).
SITE_LEAD_HOOK_TOKEN = os.environ.get("SITE_LEAD_HOOK_TOKEN", "changeme-lead")
DEPLOY_TOKEN = os.environ.get("DEPLOY_TOKEN", "changeme-deploy")
APP_DIR = os.environ.get("APP_DIR", str(BASE_DIR))
SERVICE_NAME = os.environ.get("SERVICE_NAME", "analytics.service")

# --- Доступ к CRM API (для периодического подтягивания справочников, например
# специалистов) — токен НЕ хранится в чате и НЕ приходит через деплой-архив,
# его нужно один раз вручную дописать в /etc/analytics.env на сервере. ---
CRM_API_BASE = os.environ.get("CRM_API_BASE", "https://crm3.sqns.ru")
CRM_API_TOKEN = os.environ.get("CRM_API_TOKEN", "")

# --- Доступ к Calltouch API (для бэкфилла истории звонков — вебхуки ловят
# только новые). siteId/clientApiId берутся в кабинете Calltouch →
# Интеграции → API, добавляются в /etc/analytics.env так же, как CRM_API_TOKEN. ---
CALLTOUCH_SITE_ID = os.environ.get("CALLTOUCH_SITE_ID", "")
CALLTOUCH_API_ID = os.environ.get("CALLTOUCH_API_ID", "")
CALLTOUCH_API_BASE = "https://api.calltouch.ru/calls-service/RestAPI"

# --- Яндекс Директ (автоматический импорт расходов на рекламу) ---
# YANDEX_DIRECT_TOKEN — OAuth-токен с доступом к Директ API (получается на
# oauth.yandex.ru); YANDEX_DIRECT_LOGIN — логин рекламного аккаунта в Директе,
# нужен в заголовке Client-Login, если токен агентский/представительский —
# для собственного аккаунта обычно можно оставить пустым.
YANDEX_DIRECT_TOKEN = os.environ.get("YANDEX_DIRECT_TOKEN", "")
YANDEX_DIRECT_LOGIN = os.environ.get("YANDEX_DIRECT_LOGIN", "")
YANDEX_DIRECT_API_URL = "https://api.direct.yandex.com/json/v5/reports"

# --- Вход в дашборд (данные пациентов — персональные, доступ только после
# пароля). Раньше это была HTTP Basic Auth на уровне nginx — у неё есть
# известная дыра: если отменить системный диалог браузера, в некоторых
# случаях (bfcache/кэш) содержимое страницы всё равно показывается, потому
# что браузер, а не сервер, решает, что делать с "отменой", и может отдать
# страницу из памяти без нового запроса. Поэтому вход теперь на уровне
# самого приложения: без валидной сессии сервер вообще не отдаёт HTML —
# отменить нечего, сама форма логина полностью под нашим контролем. ---
DASH_PASSWORD = os.environ.get("DASH_PASSWORD", "")
SESSION_SECRET = os.environ.get("SESSION_SECRET", "")
SESSION_COOKIE = "cp_session"
SESSION_MAX_AGE = 60 * 60 * 24 * 14  # 14 дней


def _sign_session(expires_at: int) -> str:
    msg = str(expires_at).encode("utf-8")
    sig = hmac.new(SESSION_SECRET.encode("utf-8"), msg, hashlib.sha256).hexdigest()
    return f"{expires_at}.{sig}"


def _verify_session(token: str | None) -> bool:
    if not token or not SESSION_SECRET:
        return False
    try:
        expires_str, sig = token.split(".", 1)
        expected = hmac.new(SESSION_SECRET.encode("utf-8"), expires_str.encode("utf-8"), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, expected):
            return False
        return int(expires_str) > time.time()
    except (ValueError, TypeError):
        return False


_PUBLIC_PREFIXES = ("/static/", "/hooks/", "/internal/", "/login")

app = FastAPI()
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")


@app.middleware("http")
async def _require_login(request: Request, call_next):
    path = request.url.path
    if path.startswith(_PUBLIC_PREFIXES):
        response = await call_next(request)
    elif _verify_session(request.cookies.get(SESSION_COOKIE)):
        response = await call_next(request)
    elif request.method == "GET":
        next_q = urllib.parse.quote(path + ("?" + request.url.query if request.url.query else ""))
        response = RedirectResponse(url=f"/login?next={next_q}", status_code=303)
    else:
        response = PlainTextResponse("Unauthorized — войдите заново", status_code=401)
    # Персональные данные пациентов ни на одной защищённой странице не должны
    # оседать в кэше браузера/bfcache — иначе тот же класс проблемы вернётся
    # в другом виде (страница показывается из памяти без проверки сессии).
    if not path.startswith("/static/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, private"
        response.headers["Pragma"] = "no-cache"
    return response


def _safe_next(raw: str | None) -> str:
    next_url = raw or "/"
    if not next_url.startswith("/") or next_url.startswith("//"):
        next_url = "/"  # защита от open redirect через чужой next=
    return next_url


@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    next_url = _safe_next(request.query_params.get("next"))
    if _verify_session(request.cookies.get(SESSION_COOKIE)):
        return RedirectResponse(url=next_url, status_code=303)
    return templates.TemplateResponse(
        "login.html",
        {
            "request": request,
            "error": request.query_params.get("error"),
            "next": next_url,
        },
    )


@app.post("/login")
async def login_submit(request: Request):
    form = await request.form()
    password = str(form.get("password") or "")
    next_url = _safe_next(str(form.get("next") or "/"))
    if not DASH_PASSWORD or not SESSION_SECRET:
        return RedirectResponse(url="/login?error=notconfigured", status_code=303)
    if not secrets.compare_digest(password, DASH_PASSWORD):
        return RedirectResponse(url=f"/login?error=1&next={urllib.parse.quote(next_url)}", status_code=303)
    expires_at = int(time.time()) + SESSION_MAX_AGE
    resp = RedirectResponse(url=next_url, status_code=303)
    resp.set_cookie(
        SESSION_COOKIE, _sign_session(expires_at), max_age=SESSION_MAX_AGE,
        httponly=True, secure=True, samesite="lax",
    )
    return resp


@app.post("/logout")
async def logout():
    resp = RedirectResponse(url="/login", status_code=303)
    resp.delete_cookie(SESSION_COOKIE)
    return resp

init_db()

# --- Live-обновления через Server-Sent Events ---
_subscribers: set[asyncio.Queue] = set()


def _notify():
    for q in list(_subscribers):
        try:
            q.put_nowait("refresh")
        except asyncio.QueueFull:
            pass


@app.get("/events")
async def sse(request: Request):
    async def gen():
        q: asyncio.Queue = asyncio.Queue(maxsize=10)
        _subscribers.add(q)
        try:
            yield "event: hello\ndata: connected\n\n"
            while True:
                if await request.is_disconnected():
                    break
                try:
                    msg = await asyncio.wait_for(q.get(), timeout=15)
                    yield f"event: refresh\ndata: {msg}\n\n"
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"
        finally:
            _subscribers.discard(q)

    return StreamingResponse(gen(), media_type="text/event-stream")


# ---------------------------------------------------------------------------
# Периодическая синхронизация справочника специалистов из CRM (GET /api/v2/employee).
# Вебхуки CRM шлют только события по visit/client/payment — списка сотрудников
# среди них нет, поэтому тянем его сами по расписанию (раз в 6 часов + один раз
# при старте сервиса).
# ---------------------------------------------------------------------------
_last_employee_sync: dict = {"ok": None, "at": None, "count": None, "error": None}


def _crm_api_get(path: str, params: dict | None = None) -> dict:
    url = f"{CRM_API_BASE}{path}"
    if params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {CRM_API_TOKEN}"})
    with urllib.request.urlopen(req, timeout=20) as resp:
        return json.loads(resp.read().decode("utf-8"))


async def _sync_employees():
    global _last_employee_sync
    if not CRM_API_TOKEN:
        _last_employee_sync = {
            "ok": False, "at": datetime.utcnow().isoformat(), "count": None,
            "error": "CRM_API_TOKEN не задан в /etc/analytics.env — синхронизация специалистов пропущена",
        }
        return
    try:
        page = 1
        total = 0
        while True:
            raw = await asyncio.to_thread(_crm_api_get, "/api/v2/employee", {"page": page, "perPage": 100})
            # Реальная обёртка ответа (подтверждено живым запросом) — вложена ещё
            # на один уровень глубже документации: {"resources": {"data": [...], "meta": {...}}}
            block = (raw or {}).get("resources") or raw or {}
            items = block.get("data") or []
            for emp in items:
                crm_id = emp.get("id")
                try:
                    crm_id = int(crm_id)
                except (TypeError, ValueError):
                    pass
                upsert_employee(
                    {
                        "crm_id": crm_id,
                        "firstname": emp.get("firstname") or None,
                        "lastname": emp.get("lastname") or None,
                        "patronymic": emp.get("patronymic") or None,
                        "position": emp.get("position") or None,
                        "is_fired": 1 if emp.get("isFired") else 0,
                        "is_deleted": 1 if emp.get("isDeleted") else 0,
                        "raw_json": json.dumps(emp, ensure_ascii=False),
                    }
                )
                total += 1
            meta = block.get("meta") or {}
            last_page = int(meta.get("lastPage") or 1)
            if not items or page >= last_page:
                break
            page += 1
        _last_employee_sync = {"ok": True, "at": datetime.utcnow().isoformat(), "count": total, "error": None}
        log_webhook("crm_sync", True, f"специалистов синхронизировано: {total}", {})
        _notify()
    except Exception as e:  # noqa: BLE001 — синхронизация не должна ронять сервис
        _last_employee_sync = {"ok": False, "at": datetime.utcnow().isoformat(), "count": None, "error": str(e)}
        log_webhook("crm_sync", False, str(e), {})


async def _employee_sync_loop():
    while True:
        await _sync_employees()
        await asyncio.sleep(6 * 3600)


@app.on_event("startup")
async def _on_startup():
    asyncio.create_task(_employee_sync_loop())
    asyncio.create_task(_yandex_direct_daily_loop())


# ---------------------------------------------------------------------------
# Разовый бэкфилл исторических данных из CRM (клиенты + визиты за произвольный
# период, например «весь 2026 год») — вебхуки ловят только НОВЫЕ события,
# старые визиты/клиенты ими не покрываются.
# ---------------------------------------------------------------------------
def _to_int(val):
    try:
        return int(val)
    except (TypeError, ValueError):
        return None


def _unwrap_list(raw) -> tuple:
    """Реальный формат ответов CRM для списков как минимум один раз (employee)
    отличался от документации лишним уровнем вложенности {"resources": {...}}.
    Проверяем оба варианта защитно, вместо того чтобы полагаться на спеку."""
    if not isinstance(raw, dict):
        return [], {}
    block = raw.get("resources") if isinstance(raw.get("resources"), dict) else raw
    items = block.get("data") or []
    meta = block.get("meta") or {}
    return items, meta


_backfill_status: dict = {"running": False, "started_at": None, "finished_at": None, "counts": {}, "error": None}


async def _backfill_clients() -> int:
    total = 0
    page = 1
    while True:
        raw = await asyncio.to_thread(_crm_api_get, "/api/v2/client", {"page": page, "perPage": 100})
        items, meta = _unwrap_list(raw)
        if page == 1 and items:
            log_webhook("backfill_debug", True, "образец client из /api/v2/client", items[0])
        for c in items:
            phone = c.get("phone")
            upsert_client(
                {
                    "crm_id": _to_int(c.get("id")),
                    "phone": phone,
                    "phone_norm": normalize_phone(phone),
                    "name": c.get("name") or c.get("firstname"),
                    "raw_json": json.dumps(c, ensure_ascii=False),
                }
            )
            total += 1
        last_page = _to_int((meta or {}).get("lastPage")) or 1
        if not items or page >= last_page:
            break
        page += 1
    return total


async def _backfill_visits(date_from: str, date_to: str) -> int:
    total = 0
    page = 1
    while True:
        raw = await asyncio.to_thread(
            _crm_api_get,
            "/api/v2/visit",
            {"page": page, "perPage": 100, "dateFrom": date_from, "dateTill": date_to},
        )
        items, meta = _unwrap_list(raw)
        if page == 1 and items:
            log_webhook("backfill_debug", True, "образец visit из /api/v2/visit", items[0])
        for v in items:
            client_data = v.get("clientData") or {}
            upsert_visit(
                {
                    "crm_id": _to_int(v.get("id")),
                    "client_crm_id": _to_int(v.get("clientId") or v.get("client")),
                    "resource_id": _to_int(v.get("resourceId")),
                    "visit_datetime": v.get("datetime"),
                    "total_price": _to_float(v.get("totalPrice")),
                    "is_paid": 1 if v.get("isPaid") else 0,
                    "attendance": v.get("attendance"),
                    "deleted": 1 if v.get("deleted") else 0,
                    "services_json": json.dumps(v.get("services") or [], ensure_ascii=False),
                    "raw_json": json.dumps(v, ensure_ascii=False),
                }
            )
            if client_data.get("id"):
                phone = client_data.get("phone")
                upsert_client(
                    {
                        "crm_id": _to_int(client_data.get("id")),
                        "phone": phone,
                        "phone_norm": normalize_phone(phone),
                        "name": client_data.get("name") or client_data.get("firstname"),
                        "raw_json": json.dumps(client_data, ensure_ascii=False),
                    }
                )
            total += 1
        last_page = _to_int((meta or {}).get("lastPage")) or 1
        if not items or page >= last_page:
            break
        page += 1
    return total


def _date_chunks(date_from: str, date_to: str, max_days: int = 90):
    start = datetime.strptime(date_from, "%Y-%m-%d").date()
    end = datetime.strptime(date_to, "%Y-%m-%d").date()
    cur = start
    while cur <= end:
        chunk_end = min(cur + timedelta(days=max_days - 1), end)
        yield cur.isoformat(), chunk_end.isoformat()
        cur = chunk_end + timedelta(days=1)


def _payment_crm_id(p: dict) -> int:
    # У платежа в этом эндпоинте CRM нет собственного id (подтверждено на реальных
    # данных) — строим стабильный синтетический ключ, чтобы повторный бэкфилл
    # обновлял те же записи, а не плодил дубли.
    composite = f"{p.get('clientId')}|{p.get('visitId')}|{p.get('date')}|{p.get('amount')}|{p.get('paymentTypeId')}"
    return zlib.crc32(composite.encode("utf-8"))


async def _backfill_payments(date_from: str, date_to: str) -> int:
    total = 0
    for d_from, d_to in _date_chunks(date_from, date_to, 90):
        page = 1
        while True:
            raw = await asyncio.to_thread(
                _crm_api_get,
                "/api/v2/payments",
                {"page": page, "pageSize": 100, "dateFrom": d_from, "dateTo": d_to},
            )
            items, meta = _unwrap_list(raw)
            if page == 1 and items:
                log_webhook("backfill_debug", True, f"образец payment {d_from}..{d_to}", items[0])
            for p in items:
                upsert_payment(
                    {
                        "crm_id": _payment_crm_id(p),
                        "client_crm_id": _to_int(p.get("clientId")),
                        "visit_crm_id": _to_int(p.get("visitId")),
                        "amount": _to_float(p.get("amount")),
                        "payment_method": p.get("paymentMethod"),
                        "payment_type": p.get("paymentTypeName") or p.get("paymentTypeHandle"),
                        "payment_date": p.get("date"),
                        "raw_json": json.dumps(p, ensure_ascii=False),
                    }
                )
                total += 1
            if not items or not meta.get("hasMore"):
                break
            page += 1
    return total


async def _run_backfill(date_from: str, date_to: str):
    global _backfill_status
    _backfill_status = {"running": True, "started_at": datetime.utcnow().isoformat(), "finished_at": None, "counts": {}, "error": None}
    try:
        clients = await _backfill_clients()
        _backfill_status["counts"]["clients"] = clients
        visits = await _backfill_visits(date_from, date_to)
        _backfill_status["counts"]["visits"] = visits
        payments = await _backfill_payments(date_from, date_to)
        _backfill_status["counts"]["payments"] = payments
        log_webhook("backfill", True, f"clients={clients} visits={visits} payments={payments} период={date_from}..{date_to}", {})
    except Exception as e:  # noqa: BLE001
        _backfill_status["error"] = str(e)
        log_webhook("backfill", False, str(e), {})
    finally:
        _backfill_status["running"] = False
        _backfill_status["finished_at"] = datetime.utcnow().isoformat()
        _notify()


@app.post("/internal/backfill")
async def start_backfill(request: Request, x_deploy_token: str = Header(default="")):
    if x_deploy_token != DEPLOY_TOKEN:
        raise HTTPException(403)
    if _backfill_status.get("running"):
        return {"status": "already_running", **_backfill_status}
    if not CRM_API_TOKEN:
        raise HTTPException(400, "CRM_API_TOKEN не задан в /etc/analytics.env")
    qp = request.query_params
    date_from = qp.get("from") or f"{datetime.utcnow().year}-01-01"
    date_to = qp.get("to") or datetime.utcnow().date().isoformat()
    asyncio.create_task(_run_backfill(date_from, date_to))
    return {"status": "started", "from": date_from, "to": date_to}


@app.get("/internal/backfill/status")
async def backfill_status():
    return _backfill_status


# ---------------------------------------------------------------------------
# Бэкфилл истории звонков из Calltouch (calls-diary API) — отдельный источник
# и отдельный формат дат (dd/mm/yyyy) от CRM, поэтому свой пайплайн.
# ---------------------------------------------------------------------------
_calltouch_backfill_status: dict = {"running": False, "started_at": None, "finished_at": None, "counts": {}, "error": None}


def _calltouch_api_get(path: str, params: dict) -> object:
    url = f"{CALLTOUCH_API_BASE}/{CALLTOUCH_SITE_ID}{path}?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url)
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _calltouch_unwrap(raw) -> list:
    if isinstance(raw, list):
        return raw
    if isinstance(raw, dict):
        return raw.get("records") or raw.get("calls") or raw.get("data") or []
    return []


def _ct_date_to_iso(s: str | None) -> str:
    """Calltouch calls-diary отдаёт дату как 'dd/mm/yyyy HH:MM:SS' (подтверждено на
    реальном ответе) — а весь остальной код фильтрует по substr(started_at,1,10)
    в формате YYYY-MM-DD, так что конвертация обязательна, иначе фильтры по
    периоду молча перестанут находить эти звонки."""
    if not s:
        return ""
    try:
        return datetime.strptime(s, "%d/%m/%Y %H:%M:%S").strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        return s


async def _backfill_calltouch(date_from: str, date_to: str) -> int:
    d_from = datetime.strptime(date_from, "%Y-%m-%d").strftime("%d/%m/%Y")
    d_to = datetime.strptime(date_to, "%Y-%m-%d").strftime("%d/%m/%Y")
    total = 0
    page = 1
    limit = 500
    while True:
        raw = await asyncio.to_thread(
            _calltouch_api_get,
            "/calls-diary/calls",
            {"clientApiId": CALLTOUCH_API_ID, "dateFrom": d_from, "dateTo": d_to, "page": page, "limit": limit},
        )
        items = _calltouch_unwrap(raw)
        if page == 1 and items:
            log_webhook("backfill_debug", True, "образец call из Calltouch calls-diary", items[0])
        if not items:
            break
        for c in items:
            calltouch_id = str(c.get("callId") or c.get("id") or "")
            if not calltouch_id:
                continue
            phone = c.get("callerNumber") or c.get("phoneNumber")
            upsert_call(
                {
                    "calltouch_id": calltouch_id,
                    "phone": phone,
                    "phone_norm": normalize_phone(phone),
                    "source": c.get("source") or c.get("utmSource"),
                    "medium": c.get("medium") or c.get("utmMedium"),
                    "campaign": c.get("utmCampaign"),
                    "term": c.get("utmTerm"),
                    "content": c.get("utmContent"),
                    "city": c.get("city"),
                    "call_phase": c.get("callphase"),
                    "status": c.get("statusDetails") or ("success" if c.get("successful") else "unknown"),
                    "is_unique": 1 if c.get("uniqueCall") else 0,
                    "is_target": 1 if c.get("targetCall") else 0,
                    "duration": _to_int(c.get("duration")) or 0,
                    "started_at": _ct_date_to_iso(c.get("date")),
                    "record_url": c.get("recordUrl") or c.get("callRecord") or c.get("record"),
                    "raw_json": json.dumps(c, ensure_ascii=False),
                }
            )
            total += 1
        if len(items) < limit:
            break
        page += 1
    return total


async def _run_calltouch_backfill(date_from: str, date_to: str):
    global _calltouch_backfill_status
    _calltouch_backfill_status = {"running": True, "started_at": datetime.utcnow().isoformat(), "finished_at": None, "counts": {}, "error": None}
    try:
        calls = await _backfill_calltouch(date_from, date_to)
        _calltouch_backfill_status["counts"]["calls"] = calls
        log_webhook("backfill", True, f"calltouch calls={calls} период={date_from}..{date_to}", {})
    except Exception as e:  # noqa: BLE001
        _calltouch_backfill_status["error"] = str(e)
        log_webhook("backfill", False, str(e), {})
    finally:
        _calltouch_backfill_status["running"] = False
        _calltouch_backfill_status["finished_at"] = datetime.utcnow().isoformat()
        _notify()


@app.post("/internal/backfill/calltouch")
async def start_calltouch_backfill(request: Request, x_deploy_token: str = Header(default="")):
    if x_deploy_token != DEPLOY_TOKEN:
        raise HTTPException(403)
    if _calltouch_backfill_status.get("running"):
        return {"status": "already_running", **_calltouch_backfill_status}
    if not CALLTOUCH_SITE_ID or not CALLTOUCH_API_ID:
        raise HTTPException(400, "CALLTOUCH_SITE_ID/CALLTOUCH_API_ID не заданы в /etc/analytics.env")
    qp = request.query_params
    date_from = qp.get("from") or f"{datetime.utcnow().year}-01-01"
    date_to = qp.get("to") or datetime.utcnow().date().isoformat()
    asyncio.create_task(_run_calltouch_backfill(date_from, date_to))
    return {"status": "started", "from": date_from, "to": date_to}


@app.get("/internal/backfill/calltouch/status")
async def calltouch_backfill_status():
    return _calltouch_backfill_status


# ---------------------------------------------------------------------------
# Яндекс Директ — автоматический импорт расходов (Reports API v5).
# Заметьте: сама Reports API — давно стабильный публичный API, но точный формат
# заголовков обработки офлайн-отчёта (коды 201/202, повтор запроса) я беру по
# общеизвестной документированной схеме, не проверял на реальном токене — как
# появится токен, стоит сверить на маленьком периоде, прежде чем гонять на весь год.
# ---------------------------------------------------------------------------
_yandex_direct_sync_status: dict = {"running": False, "started_at": None, "finished_at": None, "counts": {}, "error": None}


def _yandex_direct_fetch_report(date_from: str, date_to: str) -> str:
    body = {
        "params": {
            "SelectionCriteria": {"DateFrom": date_from, "DateTo": date_to},
            "FieldNames": ["Date", "Cost"],
            "ReportName": f"analytics-cost-{date_from}-{date_to}-{datetime.utcnow().timestamp()}",
            "ReportType": "CAMPAIGN_PERFORMANCE_REPORT",
            "DateRangeType": "CUSTOM_DATE",
            "Format": "TSV",
            "IncludeVAT": "YES",
            "IncludeDiscount": "NO",
        }
    }
    headers = {
        "Authorization": f"Bearer {YANDEX_DIRECT_TOKEN}",
        "Accept-Language": "ru",
        "processingMode": "auto",
        "returnMoneyInMicros": "false",
        "skipReportHeader": "true",
        "skipReportSummary": "true",
        "skipColumnHeader": "true",
        "Content-Type": "application/json; charset=utf-8",
    }
    if YANDEX_DIRECT_LOGIN:
        headers["Client-Login"] = YANDEX_DIRECT_LOGIN

    data = json.dumps(body).encode("utf-8")
    for attempt in range(20):  # офлайн-отчёт может собираться некоторое время — поллим
        req = urllib.request.Request(YANDEX_DIRECT_API_URL, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                return resp.read().decode("utf-8")
        except urllib.error.HTTPError as e:
            if e.code in (201, 202):
                retry_in = e.headers.get("retryIn") or e.headers.get("RetryIn") or "5"
                try:
                    delay = float(retry_in)
                except ValueError:
                    delay = 5.0
                time.sleep(min(delay, 30))
                continue
            raise RuntimeError(f"Yandex Direct API HTTP {e.code}: {e.read().decode('utf-8', 'ignore')[:500]}")
    raise RuntimeError("Yandex Direct: отчёт не собрался за отведённое время (превышено число попыток)")


def _yandex_direct_parse_tsv(tsv: str) -> dict:
    """Возвращает {YYYY-MM-01: сумма} — расходы агрегированы по месяцу для ad_spend."""
    by_month: dict = {}
    for line in tsv.splitlines():
        line = line.strip()
        if not line or "\t" not in line:
            continue
        parts = line.split("\t")
        if len(parts) < 2:
            continue
        date_str, cost_str = parts[0], parts[1]
        cost = _to_float(cost_str)
        if cost is None or not date_str[:4].isdigit():
            continue
        month_key = f"{date_str[:7]}-01"
        by_month[month_key] = by_month.get(month_key, 0.0) + cost
    return by_month


async def _sync_yandex_direct(date_from: str, date_to: str) -> int:
    tsv = await asyncio.to_thread(_yandex_direct_fetch_report, date_from, date_to)
    log_webhook("backfill_debug", True, f"образец ответа Yandex Direct Reports {date_from}..{date_to}", {"raw_head": tsv[:500]})
    by_month = _yandex_direct_parse_tsv(tsv)
    for month_key, amount in by_month.items():
        upsert_ad_spend(
            {"channel": "yandex_direct", "period_date": month_key, "amount": round(amount, 2), "source": "api"}
        )
    return len(by_month)


async def _run_yandex_direct_sync(date_from: str, date_to: str):
    global _yandex_direct_sync_status
    _yandex_direct_sync_status = {"running": True, "started_at": datetime.utcnow().isoformat(), "finished_at": None, "counts": {}, "error": None}
    try:
        months = await _sync_yandex_direct(date_from, date_to)
        _yandex_direct_sync_status["counts"]["months"] = months
        log_webhook("backfill", True, f"yandex_direct месяцев={months} период={date_from}..{date_to}", {})
    except Exception as e:  # noqa: BLE001
        _yandex_direct_sync_status["error"] = str(e)
        log_webhook("backfill", False, str(e), {})
    finally:
        _yandex_direct_sync_status["running"] = False
        _yandex_direct_sync_status["finished_at"] = datetime.utcnow().isoformat()
        _notify()


@app.post("/internal/sync-yandex-direct")
async def start_yandex_direct_sync(request: Request, x_deploy_token: str = Header(default="")):
    if x_deploy_token != DEPLOY_TOKEN:
        raise HTTPException(403)
    if _yandex_direct_sync_status.get("running"):
        return {"status": "already_running", **_yandex_direct_sync_status}
    if not YANDEX_DIRECT_TOKEN:
        raise HTTPException(400, "YANDEX_DIRECT_TOKEN не задан в /etc/analytics.env")
    qp = request.query_params
    date_from = qp.get("from") or f"{datetime.utcnow().year}-01-01"
    date_to = qp.get("to") or datetime.utcnow().date().isoformat()
    asyncio.create_task(_run_yandex_direct_sync(date_from, date_to))
    return {"status": "started", "from": date_from, "to": date_to}


@app.get("/internal/sync-yandex-direct/status")
async def yandex_direct_sync_status():
    return _yandex_direct_sync_status


async def _yandex_direct_daily_loop():
    # Раз в сутки подтягиваем расходы за последние 35 дней — не только "вчера",
    # т.к. Директ иногда досчитывает/корректирует статистику задним числом.
    while True:
        await asyncio.sleep(24 * 3600)
        if not YANDEX_DIRECT_TOKEN:
            continue
        date_to = datetime.utcnow().date()
        date_from = date_to - timedelta(days=35)
        await _run_yandex_direct_sync(date_from.isoformat(), date_to.isoformat())


# ---------------------------------------------------------------------------
# Вебхук CRM (crm3.sqns.ru) — регистрируется через POST /api/v2/hook_settings
# Точная форма payload уточняется по факту первых реальных вызовов (см. webhook_log).
# ---------------------------------------------------------------------------
@app.post("/hooks/crm/{token}")
async def crm_webhook(token: str, request: Request):
    if token != CRM_HOOK_TOKEN:
        raise HTTPException(404)
    try:
        payload = await request.json()
    except Exception:
        payload = {"_raw_body": (await request.body()).decode("utf-8", "ignore")}

    try:
        _handle_crm_payload(payload)
        log_webhook("crm", True, None, payload)
    except Exception as e:  # noqa: BLE001 — не роняем вебхук из-за ошибки маппинга
        log_webhook("crm", False, str(e), payload)
        return {"status": "logged_with_error", "error": str(e)}

    _notify()
    return {"status": "ok"}


def _handle_crm_payload(payload: dict):
    """Разбирает событие CRM. Реальный формат (подтверждён живым вебхуком):
    {"orgId":.., "type": "update"|"create"|"delete", "object": "visit"|"client"|"payment",
     "<object>": {...сама сущность...}}
    """
    obj_type = payload.get("object")
    data = payload.get(obj_type) if obj_type else None
    if not isinstance(data, dict):
        # на случай другого формата — подстраховка под старые варианты
        data = payload.get("data", payload)

    if obj_type == "visit" or ({"resourceId", "datetime"} & data.keys()):
        client_data = data.get("clientData") or {}
        upsert_visit(
            {
                "crm_id": data.get("id"),
                "client_crm_id": data.get("client") or data.get("clientId"),
                "resource_id": data.get("resourceId"),
                "visit_datetime": data.get("datetime"),
                "total_price": _to_float(data.get("totalPrice")),
                "is_paid": 1 if data.get("isPaid") else 0,
                "attendance": data.get("attendance"),
                "deleted": 1 if data.get("deleted") else 0,
                "services_json": json.dumps(data.get("services") or [], ensure_ascii=False),
                "raw_json": json.dumps(data, ensure_ascii=False),
            }
        )
        # Клиент почти всегда приходит вложенным в clientData — сразу обновляем и его
        if client_data.get("id"):
            phone = client_data.get("phone")
            upsert_client(
                {
                    "crm_id": client_data.get("id"),
                    "phone": phone,
                    "phone_norm": normalize_phone(phone),
                    "name": client_data.get("name") or client_data.get("firstname"),
                    "raw_json": json.dumps(client_data, ensure_ascii=False),
                }
            )
        return

    if obj_type == "payment" or ({"paymentMethod", "paymentType"} & data.keys()):
        upsert_payment(
            {
                "crm_id": data.get("id"),
                "client_crm_id": data.get("client") or data.get("clientId"),
                "visit_crm_id": data.get("visit") or data.get("visitId"),
                "amount": _to_float(data.get("amount") or data.get("sum") or data.get("total")),
                "payment_method": data.get("paymentMethod"),
                "payment_type": data.get("paymentType"),
                "payment_date": data.get("date") or data.get("paymentDate") or data.get("create_date"),
                "raw_json": json.dumps(data, ensure_ascii=False),
            }
        )
        return

    if obj_type == "client" or "phone" in data:
        phone = data.get("phone")
        upsert_client(
            {
                "crm_id": data.get("id"),
                "phone": phone,
                "phone_norm": normalize_phone(phone),
                "name": data.get("name") or data.get("firstname"),
                "raw_json": json.dumps(data, ensure_ascii=False),
            }
        )
        return

    raise ValueError(f"Не удалось определить тип сущности CRM: object={obj_type!r}, ключи={list(data.keys())}")


# ---------------------------------------------------------------------------
# Вебхук Calltouch — точные имена полей нужно свериться с превью запроса,
# которое Calltouch показывает при настройке интеграции. Пока принимаем
# максимально широко (GET и POST, query и body) и пробуем несколько
# распространённых вариантов именования.
# ---------------------------------------------------------------------------
def _first(d: dict, *keys):
    for k in keys:
        if k in d and d[k] not in (None, ""):
            return d[k]
    return None


@app.api_route("/hooks/calltouch/{token}", methods=["GET", "POST"])
async def calltouch_webhook(token: str, request: Request):
    if token != CALLTOUCH_HOOK_TOKEN:
        raise HTTPException(404)

    params = dict(request.query_params)
    if request.method == "POST":
        try:
            body = await request.json()
            if isinstance(body, dict):
                params.update(body)
        except Exception:
            try:
                form = await request.form()
                params.update(dict(form))
            except Exception:
                pass

    def _truthy(v) -> bool:
        return str(v).strip().lower() in ("1", "true", "yes", "да")

    try:
        # В этот же вебхук прилетают и события по заявкам (requestId/leadtype),
        # не только звонки — заявки пока не пишем в calls, только в лог.
        call_phase = _first(params, "callphase")
        is_call_event = bool(call_phase) or bool(_first(params, "callerphone", "duration"))
        if not is_call_event:
            log_webhook("calltouch", True, "skipped: не похоже на событие звонка (вероятно, заявка)", params)
            _notify()
            return {"status": "ok_skipped"}

        phone = _first(params, "callerphone", "phonenumber")
        row = {
            "calltouch_id": str(_first(params, "id") or ""),
            "phone": phone,
            "phone_norm": normalize_phone(phone),
            "source": _first(params, "source", "utm_source"),
            "medium": _first(params, "medium", "utm_medium"),
            "campaign": _first(params, "utm_campaign"),
            "term": _first(params, "utm_term"),
            "content": _first(params, "utm_content"),
            "city": _first(params, "city"),
            "call_phase": call_phase,
            "status": _first(params, "status", "statusDetails"),
            "is_unique": 1 if _truthy(_first(params, "unique")) else 0,
            "is_target": 1 if _truthy(_first(params, "targetcall")) else 0,
            "duration": int(_first(params, "duration") or 0) if str(_first(params, "duration") or "").isdigit() else 0,
            "started_at": _first(params, "calltime", "timestamp", "requestDate") or datetime.utcnow().isoformat(),
            "record_url": _first(params, "reclink"),
            "raw_json": json.dumps(params, ensure_ascii=False),
        }
        if not row["calltouch_id"]:
            row["calltouch_id"] = f"noid-{datetime.utcnow().timestamp()}"
        upsert_call(row)
        log_webhook("calltouch", True, None, params)
    except Exception as e:  # noqa: BLE001
        log_webhook("calltouch", False, str(e), params)
        return {"status": "logged_with_error", "error": str(e)}

    _notify()
    return {"status": "ok"}


# ---------------------------------------------------------------------------
# Вебхук с лид-форм сайта (Tilda) — «Заявки». Онлайн-запись на сайте уходит
# напрямую в CRM (тот же движок, что app.1denta.ru) и уже ловится вебхуком
# /hooks/crm/{token} выше — сюда попадают именно обычные лид-формы («Выберите,
# что вас беспокоит» и другие уникальные формы на отдельных страницах).
#
# Tilda сама умеет слать данные формы на свой URL: Настройки сайта → Формы →
# Webhook. Формат — POST, не JSON, а form-data (application/x-www-form-urlencoded).
# Источник трафика (utm_source и т.п.) и свой visitor_id форма получает из
# скрытых полей, которые перед отправкой заполняет наш JS-сниппет на сайте —
# именно поэтому мы просто ищем их по имени, а не гадаем случайно ли Tilda их
# передаёт сама. Как и с Calltouch/CRM, точный набор ПОЛЕЙ САМОЙ ФОРМЫ
# (телефон/имя/сообщение) уточняется по факту первых реальных отправок — до
# этого момента пробуем несколько вероятных вариантов имени поля, а сырой
# payload целиком всегда сохраняется в raw_json, чтобы ничего не терялось,
# даже если наши догадки окажутся неточными.
# ---------------------------------------------------------------------------
_PHONE_FIELD_KEYS = ("Phone", "phone", "Телефон", "телефон", "Ваш телефон", "tel")
_NAME_FIELD_KEYS = ("Name", "name", "Имя", "имя", "Ваше имя")
_MESSAGE_FIELD_KEYS = ("Message", "message", "Опишите проблему", "Комментарий", "comment")
_PAGEURL_FIELD_KEYS = ("PAGEURL", "pageurl", "page_url", "Referer", "referer")


@app.post("/hooks/site-lead/{token}")
async def site_lead_webhook(token: str, request: Request):
    if token != SITE_LEAD_HOOK_TOKEN:
        raise HTTPException(404)

    params: dict = {}
    try:
        form = await request.form()
        params = dict(form)
    except Exception:
        try:
            body = await request.json()
            if isinstance(body, dict):
                params = body
        except Exception:
            pass

    try:
        phone = _first(params, *_PHONE_FIELD_KEYS)
        row = {
            "tilda_tranid": str(_first(params, "tranid") or ""),
            "form_id": str(_first(params, "formid") or ""),
            "page_url": _first(params, *_PAGEURL_FIELD_KEYS),
            "name": _first(params, *_NAME_FIELD_KEYS),
            "phone": phone,
            "phone_norm": normalize_phone(phone),
            "message": _first(params, *_MESSAGE_FIELD_KEYS),
            "source": _first(params, "utm_source"),
            "medium": _first(params, "utm_medium"),
            "campaign": _first(params, "utm_campaign"),
            "term": _first(params, "utm_term"),
            "content": _first(params, "utm_content"),
            "visitor_id": _first(params, "visitor_id"),
            "raw_json": json.dumps(params, ensure_ascii=False),
        }
        if not row["tilda_tranid"]:
            row["tilda_tranid"] = f"noid-{datetime.utcnow().timestamp()}"
        upsert_site_lead(row)
        log_webhook("site_lead", True, None, params)
    except Exception as e:  # noqa: BLE001
        log_webhook("site_lead", False, str(e), params)
        return {"status": "logged_with_error", "error": str(e)}

    _notify()
    return {"status": "ok"}


# ---------------------------------------------------------------------------
# Деплой без SSH: HTTPS-точка, которую дёргает Claude при обновлении кода.
# ---------------------------------------------------------------------------
@app.post("/internal/deploy")
async def deploy(request: Request, x_deploy_token: str = Header(default="")):
    if x_deploy_token != DEPLOY_TOKEN:
        raise HTTPException(403)
    body = await request.body()
    try:
        with tarfile.open(fileobj=io.BytesIO(body), mode="r:gz") as tf:
            skip = {"data.db", "data.db-wal", "data.db-shm"}
            safe_members = [
                m for m in tf.getmembers()
                if m.name not in skip and ".." not in Path(m.name).parts and not m.name.startswith("/")
            ]
            try:
                tf.extractall(APP_DIR, members=safe_members, filter="data")
            except TypeError:
                # старый Python без поддержки filter= (< 3.11.4) — извлекаем как есть,
                # список members уже отфильтрован от path traversal и файлов БД
                tf.extractall(APP_DIR, members=safe_members)
    except HTTPException:
        raise
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, f"bad archive: {e}")

    subprocess.run(["sudo", "systemctl", "restart", SERVICE_NAME], check=False)
    return {"status": "deployed"}


@app.get("/internal/health")
async def health():
    with get_db() as conn:
        site_leads_total = conn.execute("SELECT COUNT(*) AS n FROM site_leads").fetchone()["n"]
        site_leads_last = conn.execute(
            "SELECT created_at, phone, source, form_id FROM site_leads ORDER BY id DESC LIMIT 1"
        ).fetchone()
    return {
        "status": "ok",
        "time": datetime.utcnow().isoformat(),
        "crm_api_token_configured": bool(CRM_API_TOKEN),
        "calltouch_api_configured": bool(CALLTOUCH_SITE_ID and CALLTOUCH_API_ID),
        "yandex_direct_configured": bool(YANDEX_DIRECT_TOKEN),
        "employee_sync": _last_employee_sync,
        "backfill": _backfill_status,
        "calltouch_backfill": _calltouch_backfill_status,
        "yandex_direct_sync": _yandex_direct_sync_status,
        # Удобно проверить сразу после настройки Webhook в Tilda, не дожидаясь
        # готового интерфейса «Заявок» — видно, дошла ли хоть одна тестовая отправка.
        "site_leads_total": site_leads_total,
        "site_leads_last": dict(site_leads_last) if site_leads_last else None,
    }


@app.post("/internal/sync-employees")
async def sync_employees_now(x_deploy_token: str = Header(default="")):
    """Ручной запуск синхронизации специалистов — удобно дёрнуть сразу после
    того, как в /etc/analytics.env добавили CRM_API_TOKEN, не дожидаясь
    следующего 6-часового цикла."""
    if x_deploy_token != DEPLOY_TOKEN:
        raise HTTPException(403)
    await _sync_employees()
    return _last_employee_sync


# ---------------------------------------------------------------------------
# Дашборд
# ---------------------------------------------------------------------------
def _parse_period(request: Request) -> tuple[str, str]:
    today = datetime.utcnow().date()
    date_from = request.query_params.get("from") or (today - timedelta(days=30)).isoformat()
    date_to = request.query_params.get("to") or today.isoformat()
    return date_from, date_to


_MONTH_NAMES_RU = [
    "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
    "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь",
]


def _recent_months(n: int = 15) -> list:
    """Последние n месяцев (включая текущий) для выпадающего списка на воронке."""
    today = datetime.utcnow().date()
    y, m = today.year, today.month
    months = []
    for _ in range(n):
        months.append({"value": f"{y:04d}-{m:02d}", "label": f"{_MONTH_NAMES_RU[m - 1]} {y}"})
        m -= 1
        if m == 0:
            m = 12
            y -= 1
    return months


def _recent_years(n: int = 6) -> list:
    """Последние n лет (включая текущий) для выпадающего списка «Год» — считается
    от текущей даты сервера, поэтому 1 января следующего года список сам
    сдвинется и ничего вручную переписывать не нужно."""
    current = datetime.utcnow().year
    return list(range(current, current - n, -1))


def _recent_weeks(n: int = 10) -> list:
    """Последние n недель (пн—вс, включая текущую) для страницы «Звонки» —
    там год не нужен (столько истории звонков не нужно смотреть разом), а вот
    неделя — самая частая единица работы менеджера с журналом звонков."""
    today = datetime.utcnow().date()
    monday = today - timedelta(days=today.weekday())
    weeks = []
    for i in range(n):
        start = monday - timedelta(days=7 * i)
        end = start + timedelta(days=6)
        weeks.append({"value": start.isoformat(), "label": f"{start.strftime('%d.%m')}–{end.strftime('%d.%m')}"})
    return weeks


def _detect_calls_period_mode(date_from: str, date_to: str) -> str:
    """Как _detect_period_mode, но для «Звонков»: там недели вместо годов —
    смотреть звонки сразу за год неудобно, менеджер работает неделями/месяцами."""
    try:
        d_from = datetime.strptime(date_from, "%Y-%m-%d").date()
        d_to = datetime.strptime(date_to, "%Y-%m-%d").date()
    except ValueError:
        return "custom"

    if d_from.weekday() == 0 and (d_to - d_from).days == 6:
        return "week"

    if d_from.day == 1 and d_from.year == d_to.year and d_from.month == d_to.month:
        next_month = (d_from.replace(day=28) + timedelta(days=4)).replace(day=1)
        last_day_of_month = next_month - timedelta(days=1)
        if d_to == last_day_of_month:
            return "month"

    return "custom"


def _detect_period_mode(date_from: str, date_to: str) -> str:
    """Определяет, какой режим выбора периода соответствует уже выбранным
    датам — чтобы при открытии страницы сразу подсветить нужную вкладку
    (Месяц/Год/Свой период), а не всегда показывать «Свой период»."""
    try:
        d_from = datetime.strptime(date_from, "%Y-%m-%d").date()
        d_to = datetime.strptime(date_to, "%Y-%m-%d").date()
    except ValueError:
        return "custom"
    today = datetime.utcnow().date()

    if d_from.month == 1 and d_from.day == 1 and d_from.year == d_to.year:
        is_full_year = d_to.month == 12 and d_to.day == 31
        is_ytd_current_year = d_from.year == today.year and d_to == today
        if is_full_year or is_ytd_current_year:
            return "year"

    if d_from.day == 1 and d_from.year == d_to.year and d_from.month == d_to.month:
        next_month = (d_from.replace(day=28) + timedelta(days=4)).replace(day=1)
        last_day_of_month = next_month - timedelta(days=1)
        if d_to == last_day_of_month:
            return "month"

    return "custom"


def _period_label(date_from: str, date_to: str, mode: str) -> str:
    """Короткая человекочитаемая подпись на кнопке-триггере поп-апа периода —
    «Август 2026», «2026», «17.08–23.08» или диапазон дат для своего периода."""
    try:
        d_from = datetime.strptime(date_from, "%Y-%m-%d").date()
        d_to = datetime.strptime(date_to, "%Y-%m-%d").date()
    except ValueError:
        return f"{date_from} – {date_to}"
    if mode == "month":
        return f"{_MONTH_NAMES_RU[d_from.month - 1]} {d_from.year}"
    if mode == "year":
        return str(d_from.year)
    if mode == "week":
        return f"{d_from.strftime('%d.%m')}–{d_to.strftime('%d.%m')}"
    return f"{d_from.strftime('%d.%m.%Y')} – {d_to.strftime('%d.%m.%Y')}"


def _compute_funnel_metrics(conn, calls) -> dict:
    """Общее ядро расчёта воронки по уже отфильтрованному списку звонков —
    переиспользуется и для страницы «Воронка», и для разбивки по каналам."""
    total_calls = len(calls)
    unique_phones = {c["phone_norm"] for c in calls if c["phone_norm"]}
    target_calls = sum(1 for c in calls if c["is_target"])

    if not unique_phones:
        return {
            "total_calls": total_calls, "unique_calls": 0, "target_calls": target_calls,
            "leads": 0, "visited": 0, "paid": 0, "revenue": 0.0,
        }

    placeholders = ",".join("?" for _ in unique_phones)
    clients = conn.execute(
        f"SELECT crm_id, phone_norm FROM crm_clients WHERE phone_norm IN ({placeholders})",
        list(unique_phones),
    ).fetchall()
    leads = len(clients)
    client_ids = [c["crm_id"] for c in clients]

    visited = 0
    paid = 0
    revenue = 0.0
    if client_ids:
        ph = ",".join("?" for _ in client_ids)
        visits = conn.execute(
            f"""SELECT client_crm_id FROM crm_visits
                WHERE client_crm_id IN ({ph}) AND deleted = 0""",
            client_ids,
        ).fetchall()
        visited_clients = {v["client_crm_id"] for v in visits}
        visited = len(visited_clients)

        # Оплату считаем по отдельной сущности "платежи", а не по visit.isPaid —
        # в этой CRM оплаты приходят отдельным объектом (object: "payment").
        payments = conn.execute(
            f"""SELECT client_crm_id, amount FROM crm_payments
                WHERE client_crm_id IN ({ph})""",
            client_ids,
        ).fetchall()
        paid_clients = {p["client_crm_id"] for p in payments if p["client_crm_id"] is not None}
        paid = len(paid_clients)
        revenue = sum(p["amount"] or 0 for p in payments)

    return {
        "total_calls": total_calls,
        "unique_calls": len(unique_phones),
        "target_calls": target_calls,
        "leads": leads,
        "visited": visited,
        "paid": paid,
        "revenue": round(revenue, 2),
    }


def _funnel_data(date_from: str, date_to: str, source: str | None):
    with get_db() as conn:
        source_rows = conn.execute(
            "SELECT DISTINCT source, medium FROM calls WHERE source IS NOT NULL"
        ).fetchall()
        # человекочитаемые варианты для фильтра — (подпись, сырое значение source),
        # дедуп по подписи (платный/органический Яндекс уже разведены самой _humanize_source)
        label_to_raw: dict = {}
        for r in source_rows:
            label = _humanize_source(r["source"], r["medium"])
            label_to_raw.setdefault(label, r["source"])
        all_sources = sorted(label_to_raw.items())

        q = """
            SELECT id, phone_norm, source, medium, is_target
            FROM calls
            WHERE substr(started_at,1,10) BETWEEN ? AND ?
        """
        args = [date_from, date_to]
        if source:
            q += " AND source = ?"
            args.append(source)
        calls = conn.execute(q, args).fetchall()

        metrics = _compute_funnel_metrics(conn, calls)
        metrics["sources"] = all_sources
        metrics["source_label"] = _humanize_source(source) if source else "Все каналы"

        # Расходы за период — приоритет автоимпорту (Директ) над ручным вводом
        # (см. _ad_spend_by_channel). Если выбран конкретный источник — пробуем
        # сопоставить его с рекламным каналом (medium у фильтра воронки нет, поэтому
        # смотрим, преобладают ли среди этих звонков платные medium, как эвристику).
        spend_by_channel = _ad_spend_by_channel(conn, date_from, date_to)
        if source:
            has_paid = any((c["medium"] or "").strip().lower() in _PAID_MEDIUMS for c in calls)
            channel_key = _map_channel(source, "cpc" if has_paid else None)
            spend = spend_by_channel.get(channel_key) if channel_key else None
        else:
            spend = sum(spend_by_channel.values()) if spend_by_channel else None
        metrics["spend"] = round(spend, 2) if spend else None

        def _cost_per(count):
            return round(spend / count, 0) if spend and count else None

        metrics["cost_per_call"] = _cost_per(metrics["total_calls"])
        metrics["cost_per_target_call"] = _cost_per(metrics["target_calls"])
        metrics["cpl"] = _cost_per(metrics["leads"])
        metrics["cost_per_visit"] = _cost_per(metrics["visited"])
        metrics["cpa"] = _cost_per(metrics["paid"])
        return metrics


FUNNEL_STAGE_LABELS = {
    "total_calls": "Все звонки",
    "target_calls": "Целевые звонки",
    "leads": "Лиды (найдены в CRM)",
    "visited": "Дошли до визита",
    "paid": "Оплатили",
}


def _funnel_stage_phones(conn, date_from: str, date_to: str, source: str | None, stage: str) -> list:
    """Список телефонов (+ имя, если известно) для конкретного блока воронки —
    для drill-down по клику на цифру."""
    q = """
        SELECT id, phone, phone_norm, is_target
        FROM calls
        WHERE substr(started_at,1,10) BETWEEN ? AND ?
    """
    args = [date_from, date_to]
    if source:
        q += " AND source = ?"
        args.append(source)
    calls = conn.execute(q, args).fetchall()
    if stage == "target_calls":
        calls = [c for c in calls if c["is_target"]]

    phone_by_norm: dict = {}
    for c in calls:
        if c["phone_norm"]:
            phone_by_norm.setdefault(c["phone_norm"], c["phone"] or c["phone_norm"])

    norms = set(phone_by_norm)
    if not norms:
        return []

    if stage not in ("total_calls", "target_calls"):
        placeholders = ",".join("?" for _ in norms)
        clients = conn.execute(
            f"SELECT crm_id, phone_norm FROM crm_clients WHERE phone_norm IN ({placeholders})",
            list(norms),
        ).fetchall()
        if stage == "leads":
            norms = {c["phone_norm"] for c in clients if c["phone_norm"]}
        elif stage in ("visited", "paid"):
            client_ids = [c["crm_id"] for c in clients]
            norm_by_id = {c["crm_id"]: c["phone_norm"] for c in clients}
            if not client_ids:
                return []
            ph = ",".join("?" for _ in client_ids)
            if stage == "visited":
                rows = conn.execute(
                    f"SELECT DISTINCT client_crm_id FROM crm_visits WHERE client_crm_id IN ({ph}) AND deleted = 0",
                    client_ids,
                ).fetchall()
            else:
                rows = conn.execute(
                    f"SELECT DISTINCT client_crm_id FROM crm_payments WHERE client_crm_id IN ({ph})",
                    client_ids,
                ).fetchall()
            ids = {r["client_crm_id"] for r in rows if r["client_crm_id"] is not None}
            norms = {norm_by_id[i] for i in ids if i in norm_by_id}
        else:
            return []

    if not norms:
        return []

    placeholders = ",".join("?" for _ in norms)
    named = conn.execute(
        f"SELECT phone_norm, name FROM crm_clients WHERE phone_norm IN ({placeholders})",
        list(norms),
    ).fetchall()
    name_by_norm = {n["phone_norm"]: n["name"] for n in named if n["name"]}

    result = [
        {"phone": phone_by_norm.get(norm, norm), "name": name_by_norm.get(norm) or ""}
        for norm in norms
    ]
    result.sort(key=lambda r: (r["name"] == "", r["name"], r["phone"]))
    return result


@app.get("/funnel/details", response_class=HTMLResponse)
async def funnel_details(request: Request):
    stage = request.query_params.get("stage") or ""
    if stage not in FUNNEL_STAGE_LABELS:
        raise HTTPException(400, "неизвестный блок воронки")
    date_from, date_to = _parse_period(request)
    source = request.query_params.get("source") or None
    with get_db() as conn:
        rows = _funnel_stage_phones(conn, date_from, date_to, source, stage)
    return templates.TemplateResponse(
        "_funnel_details.html",
        {"request": request, "rows": rows, "stage_label": FUNNEL_STAGE_LABELS[stage]},
    )


# ---------------------------------------------------------------------------
# Разбивка по каналам (CPL/CPA/ROMI) — /channels
# ---------------------------------------------------------------------------
AD_SPEND_CHANNELS = [
    ("yandex_direct", "Яндекс Директ"),
    ("2gis", "2ГИС"),
    ("yandex_maps", "Яндекс Карты"),
]

# Сопоставление (source, medium) звонка с ключом канала в ad_spend. Важно: source
# у Calltouch = "yandex" и для органической выдачи, и для платной рекламы —
# без medium их не различить (подтверждено на реальных звонках: source=yandex
# встречается и с medium=organic, и с medium=cpc). Поэтому платный трафик
# определяем ТОЛЬКО по medium из списка ниже, а не по одному source.
_PAID_MEDIUMS = {"cpc", "cpm", "ad", "context", "banner", "ppc"}
_ORGANIC_MEDIUMS = {"organic", "none", "referral", "(none)"}

_SOURCE_TO_CHANNEL = {
    "2gis": "2gis",
    "2гис": "2gis",
    "yandex_maps": "yandex_maps",
    "yandex.maps": "yandex_maps",
    "яндекс карты": "yandex_maps",
}


def _ad_spend_by_channel(conn, date_from: str, date_to: str) -> dict:
    """Расходы по каналам за период. Если за один и тот же канал+месяц есть и
    ручная запись, и автоматическая (импорт из Директ API) — берём ТОЛЬКО
    автоматическую, а не складываем обе: иначе расход задваивается в
    момент, когда включается автоимпорт поверх ранее введённых вручную
    месяцев. Приоритет api над manual — как и просили."""
    rows = conn.execute(
        """
        SELECT channel, period_date,
               MAX(CASE WHEN source = 'api' THEN amount END) AS api_amount,
               MAX(CASE WHEN source = 'manual' THEN amount END) AS manual_amount
        FROM ad_spend
        WHERE period_date BETWEEN ? AND ?
        GROUP BY channel, period_date
        """,
        (date_from[:7] + "-01", date_to[:7] + "-01"),
    ).fetchall()
    by_channel: dict = {}
    for r in rows:
        amount = r["api_amount"] if r["api_amount"] is not None else (r["manual_amount"] or 0.0)
        by_channel[r["channel"]] = by_channel.get(r["channel"], 0.0) + amount
    return by_channel


# Человекочитаемые русские названия источников трафика — вместо сырых тегов
# calltouch/CRM (yandex/cpc, 2gis, vk и т.п.). Список best-effort: неизвестные
# источники не ломаются, просто показываются с заглавной буквы как есть.
def _humanize_source(source: str | None, medium: str | None = None) -> str:
    if not source:
        return "Без источника"
    key = source.strip().lower()
    med = (medium or "").strip().lower()
    is_paid = med in _PAID_MEDIUMS
    is_organic = (not med) or med in _ORGANIC_MEDIUMS

    if "yandex" in key or key in ("ya", "direct.yandex"):
        if "maps" in key or "карт" in key:
            return "Яндекс Карты"
        if is_paid:
            return "Яндекс Директ"
        if is_organic:
            return "Яндекс (органика)"
        return "Яндекс"
    if "yandex_maps" in key or "yandex.maps" in key or "карт" in key:
        return "Яндекс Карты"
    if "2gis" in key or "2гис" in key or "dubl" in key:
        return "2ГИС"
    if "google" in key:
        return "Google Реклама" if is_paid else "Google (органика)"
    if key in ("vk", "vkontakte", "вконтакте"):
        return "ВКонтакте"
    if "instagram" in key or key == "ig":
        return "Instagram"
    if "facebook" in key or key == "fb":
        return "Facebook"
    if "avito" in key or "авито" in key:
        return "Авито"
    if "whatsapp" in key:
        return "WhatsApp"
    if "telegram" in key or key == "tg":
        return "Telegram"
    if key in ("direct", "(direct)"):
        return "Прямые заходы"
    if key == "referral":
        return "Переходы с сайтов"
    if key == "organic":
        return "Органический поиск"
    return source.strip().capitalize()


def _map_channel(source: str | None, medium: str | None = None) -> str | None:
    if not source:
        return None
    key = source.strip().lower()
    med = (medium or "").strip().lower()

    # Яндекс — платный канал (Директ) только если medium явно платный;
    # органика/без medium в расходы не попадает — это отдельный бесплатный канал.
    if "yandex" in key or "direct" in key:
        return "yandex_direct" if med in _PAID_MEDIUMS else None

    if key in _SOURCE_TO_CHANNEL:
        return _SOURCE_TO_CHANNEL[key]
    for needle, channel in _SOURCE_TO_CHANNEL.items():
        if needle in key:
            return channel
    return None


def _channels_data(date_from: str, date_to: str):
    with get_db() as conn:
        calls = conn.execute(
            """
            SELECT id, phone_norm, source, medium, is_target
            FROM calls
            WHERE substr(started_at,1,10) BETWEEN ? AND ?
            """,
            (date_from, date_to),
        ).fetchall()

        # Группируем по (source, medium) — иначе платный и органический Яндекс
        # схлопнутся в одну строку с одной CPL/CPA, хотя расходы есть только у платного.
        by_key: dict = {}
        for c in calls:
            key = (c["source"] or None, c["medium"] or None)
            by_key.setdefault(key, []).append(c)

        spend_by_channel = _ad_spend_by_channel(conn, date_from, date_to)

        rows = []
        for (src, med), group in sorted(by_key.items(), key=lambda kv: -len(kv[1])):
            m = _compute_funnel_metrics(conn, group)
            channel_key = _map_channel(src, med)
            label = _humanize_source(src, med)
            spend = spend_by_channel.get(channel_key) if channel_key else None
            cpl = round(spend / m["leads"], 0) if spend and m["leads"] else None
            cpa = round(spend / m["paid"], 0) if spend and m["paid"] else None
            romi = round((m["revenue"] - spend) / spend * 100, 1) if spend else None
            rows.append({
                "source": label,
                "channel_key": channel_key,
                "spend": spend,
                "cpl": cpl,
                "cpa": cpa,
                "romi": romi,
                **m,
            })

        total_spend = sum(v for v in spend_by_channel.values())
        recent_spend = conn.execute(
            "SELECT id, channel, period_date, amount, source FROM ad_spend ORDER BY period_date DESC, channel LIMIT 24"
        ).fetchall()

        # Для диаграммы «расходы по каналам» — по трём каналам ручного/автоимпорта
        # расхода (Директ/2ГИС/Карты), не по разбивке source+medium из таблицы ниже.
        spend_chart = [
            {"key": key, "label": label, "amount": round(spend_by_channel.get(key, 0.0), 2)}
            for key, label in AD_SPEND_CHANNELS
        ]
        max_chart_amount = max((c["amount"] for c in spend_chart), default=0) or 1

        return {
            "rows": rows,
            "total_spend": round(total_spend, 2),
            "spend_channels": AD_SPEND_CHANNELS,
            "channel_labels": dict(AD_SPEND_CHANNELS),
            "recent_spend": recent_spend,
            "spend_chart": spend_chart,
            "max_chart_amount": max_chart_amount,
        }


@app.get("/", response_class=HTMLResponse)
async def funnel_page(request: Request):
    date_from, date_to = _parse_period(request)
    source = request.query_params.get("source") or None
    data = _funnel_data(date_from, date_to, source)
    period_mode = _detect_period_mode(date_from, date_to)
    return templates.TemplateResponse(
        "funnel.html",
        {
            "request": request, "data": data, "date_from": date_from,
            "date_to": date_to, "source": source or "", "months": _recent_months(),
            "years": _recent_years(), "period_mode": period_mode,
            "current_month_value": date_from[:7], "current_year_value": date_from[:4],
            "period_label": _period_label(date_from, date_to, period_mode),
        },
    )


@app.get("/channels", response_class=HTMLResponse)
async def channels_page(request: Request):
    date_from, date_to = _parse_period(request)
    data = _channels_data(date_from, date_to)
    period_mode = _detect_period_mode(date_from, date_to)
    return templates.TemplateResponse(
        "channels.html",
        {
            "request": request, "data": data, "date_from": date_from, "date_to": date_to,
            "months": _recent_months(), "years": _recent_years(), "period_mode": period_mode,
            "current_month_value": date_from[:7], "current_year_value": date_from[:4],
            "period_label": _period_label(date_from, date_to, period_mode),
        },
    )


@app.post("/channels/ad-spend")
async def add_ad_spend(request: Request):
    form = await request.form()
    channel = (form.get("channel") or "").strip()
    month = (form.get("month") or "").strip()  # YYYY-MM из <input type="month">
    amount = _to_float(form.get("amount"))
    valid_channels = {c for c, _ in AD_SPEND_CHANNELS}
    if channel in valid_channels and month and amount is not None:
        upsert_ad_spend({
            "channel": channel,
            "period_date": f"{month}-01",
            "amount": amount,
            "source": "manual",
        })
        _notify()
    return RedirectResponse(url="/channels", status_code=303)


@app.post("/channels/ad-spend/{spend_id}/update")
async def update_ad_spend(spend_id: int, request: Request):
    """Редактирование ранее внесённой вручную записи о расходе. Правим только
    source='manual' — автоимпорт из Директа трогать нельзя, его перезапишет
    следующая синхронизация. Канал/месяц можно менять — технически это
    "удалить старую запись + завести новую с теми же данными, что и обычное
    добавление", чтобы не бороться с уникальным индексом (channel, period_date, source)."""
    form = await request.form()
    channel = (form.get("channel") or "").strip()
    month = (form.get("month") or "").strip()
    amount = _to_float(form.get("amount"))
    valid_channels = {c for c, _ in AD_SPEND_CHANNELS}
    if channel in valid_channels and month and amount is not None:
        period_date = f"{month}-01"
        # Delete+insert на ОДНОМ соединении (не через upsert_ad_spend, у которой
        # своё соединение) — иначе вторая транзакция ждёт снятия блокировки первой,
        # которая ещё не закоммичена, и ловим "database is locked".
        with get_db() as conn:
            row = conn.execute("SELECT source FROM ad_spend WHERE id = ?", (spend_id,)).fetchone()
            if row and row["source"] == "manual":
                conn.execute("DELETE FROM ad_spend WHERE id = ?", (spend_id,))
                conn.execute(
                    """
                    INSERT INTO ad_spend (channel, period_date, amount, source, updated_at)
                    VALUES (?, ?, ?, 'manual', datetime('now'))
                    ON CONFLICT(channel, period_date, source) DO UPDATE SET
                        amount=excluded.amount, updated_at=datetime('now')
                    """,
                    (channel, period_date, amount),
                )
        _notify()
    return RedirectResponse(url="/channels", status_code=303)


@app.post("/channels/ad-spend/{spend_id}/delete")
async def delete_ad_spend(spend_id: int):
    """Удаление ранее внесённой вручную записи о расходе (только manual —
    автоимпорт из Директа удалять нельзя, он не редактируется руками)."""
    with get_db() as conn:
        row = conn.execute("SELECT source FROM ad_spend WHERE id = ?", (spend_id,)).fetchone()
        if row and row["source"] == "manual":
            conn.execute("DELETE FROM ad_spend WHERE id = ?", (spend_id,))
    _notify()
    return RedirectResponse(url="/channels", status_code=303)


def _specialists_data(date_from: str, date_to: str) -> dict:
    with get_db() as conn:
        # Справочник специалистов — у служебной записи CRM (сама организация)
        # пустое имя, такие записи из списка убираем.
        employees = conn.execute(
            "SELECT crm_id, firstname, lastname, patronymic, position, is_deleted, is_fired "
            "FROM crm_employees WHERE firstname IS NOT NULL AND firstname != ''"
        ).fetchall()
        emp_by_id = {e["crm_id"]: e for e in employees}

        visits = conn.execute(
            """SELECT crm_id, client_crm_id, resource_id, visit_datetime, services_json
               FROM crm_visits
               WHERE deleted = 0 AND substr(visit_datetime,1,10) BETWEEN ? AND ?""",
            (date_from, date_to),
        ).fetchall()

        payments = conn.execute("SELECT client_crm_id, visit_crm_id, amount FROM crm_payments").fetchall()
        amount_by_visit: dict = {}
        for p in payments:
            if p["visit_crm_id"] is not None:
                amount_by_visit[p["visit_crm_id"]] = amount_by_visit.get(p["visit_crm_id"], 0) + (p["amount"] or 0)

        # Вся история визитов (не только период) нужна для двух вещей:
        # 1) момент первого визита пациента вообще — чтобы посчитать «новых»;
        all_visits = conn.execute(
            "SELECT crm_id, client_crm_id, resource_id, visit_datetime FROM crm_visits "
            "WHERE deleted = 0 ORDER BY visit_datetime"
        ).fetchall()

        first_visit_by_client: dict = {}
        for v in all_visits:
            cid = v["client_crm_id"]
            if cid is None:
                continue
            cur = first_visit_by_client.get(cid)
            if cur is None or (v["visit_datetime"] or "") < (cur["visit_datetime"] or ""):
                first_visit_by_client[cid] = v

        by_resource: dict = {}
        for v in visits:
            by_resource.setdefault(v["resource_id"], []).append(v)

        # Аналитика по услугам за период — разбираем services_json визитов
        # (реальный формат подтверждён на живых данных: [{"id","name","paySum","price","amount",...}]).
        services_agg: dict = {}
        for v in visits:
            raw = v["services_json"]
            if not raw or raw == "[]":
                continue
            try:
                items = json.loads(raw)
            except (TypeError, ValueError):
                continue
            for s in items or []:
                key = s.get("id") if s.get("id") is not None else s.get("name")
                if key is None:
                    continue
                entry = services_agg.setdefault(key, {"name": s.get("name") or "—", "qty": 0.0, "revenue": 0.0, "visits": 0})
                entry["qty"] += _to_float(s.get("amount")) or 0.0
                entry["revenue"] += _to_float(s.get("paySum")) or 0.0
                entry["visits"] += 1
        services = sorted(services_agg.values(), key=lambda x: -x["revenue"])[:20]

        # Конверсия «доведения первички до чека» — по формулировке Никиты: считаем
        # первичных (новых) пациентов специалиста за период, и смотрим, получил ли
        # этот пациент ХОТЬ КАКУЮ-ТО оплаченную услугу в клинике — неважно, у того
        # же специалиста или у другого (например, пациента перенаправили). Конверсия
        # засчитывается ТОМУ специалисту, к которому было первое обращение, а у
        # коллеги, которому пациента передали, этот же пациент считается повторным
        # (в его new_patients он не попадёт — это уже гарантирует first_visit_by_client).
        paid_client_ids = {
            p["client_crm_id"] for p in payments
            if p["client_crm_id"] is not None and (p["amount"] or 0) > 0
        }

        rows = []
        new_patients_total = 0
        for resource_id, group in by_resource.items():
            emp = emp_by_id.get(resource_id)
            if not emp:
                continue  # визит без сопоставленного специалиста — см. unmatched_resource_ids ниже
            name = f'{emp["lastname"] or ""} {emp["firstname"] or ""} {emp["patronymic"] or ""}'.strip()
            client_ids = {v["client_crm_id"] for v in group if v["client_crm_id"] is not None}
            revenue = sum(amount_by_visit.get(v["crm_id"], 0) for v in group)

            new_patient_ids = []
            for cid in client_ids:
                fv = first_visit_by_client.get(cid)
                if fv and fv["resource_id"] == resource_id and date_from <= (fv["visit_datetime"] or "")[:10] <= date_to:
                    new_patient_ids.append(cid)
            new_patients = len(new_patient_ids)
            new_patients_total += new_patients

            converted_patients = sum(1 for cid in new_patient_ids if cid in paid_client_ids)
            conversion_pct = round(converted_patients / new_patients * 100, 1) if new_patients else 0.0

            rows.append(
                {
                    "resource_id": resource_id,
                    "name": name or f"Специалист #{resource_id}",
                    "position": emp["position"] or "—",
                    "visits": len(group),
                    "patients": len(client_ids),
                    "new_patients": new_patients,
                    "revenue": round(revenue, 2),
                    "converted_patients": converted_patients,
                    "conversion_pct": conversion_pct,
                }
            )

        rows.sort(key=lambda r: -r["visits"])

        unmatched_resource_ids = sorted(
            {v["resource_id"] for v in visits if v["resource_id"] not in emp_by_id and v["resource_id"] is not None}
        )

        # Диаграмма эффективности: только те, у кого вообще были новые пациенты
        # за период — иначе в диаграмме будет шум из пустых 0%-строк.
        conversion_chart = sorted(
            (r for r in rows if r["new_patients"] > 0),
            key=lambda r: -r["conversion_pct"],
        )

        return {
            "rows": rows,
            "new_patients_total": new_patients_total,
            "total_patients": len({v["client_crm_id"] for v in visits if v["client_crm_id"] is not None}),
            "total_visits": len(visits),
            "unmatched_resource_ids": unmatched_resource_ids,
            "services": services,
            "conversion_chart": conversion_chart,
        }


@app.get("/specialists", response_class=HTMLResponse)
async def specialists_page(request: Request):
    date_from, date_to = _parse_period(request)
    data = _specialists_data(date_from, date_to)
    period_mode = _detect_period_mode(date_from, date_to)
    return templates.TemplateResponse(
        "specialists.html",
        {
            "request": request, "data": data, "date_from": date_from, "date_to": date_to,
            "months": _recent_months(), "years": _recent_years(), "period_mode": period_mode,
            "current_month_value": date_from[:7], "current_year_value": date_from[:4],
            "period_label": _period_label(date_from, date_to, period_mode),
        },
    )


# ---------------------------------------------------------------------------
# Спящая аудитория — /dormant
# ---------------------------------------------------------------------------
DORMANT_DAYS = 180
# В схеме CRM нет явного поля «чёрный список» — похоже, это реализовано через
# tags клиента. Пока фильтруем по ключевым словам в тегах; если у вас точная
# формулировка тега другая — скажите, поправим список меток.
_BLACKLIST_TAG_HINTS = ("чёрн", "черн", "стоп-лист", "стоп список", "blacklist", "бан")

VALID_DORMANT_STATUSES = {"new", "contacted", "no_answer", "booked", "refused"}
DORMANT_STATUS_LABELS = {
    "new": "Нет контакта",
    "contacted": "На связи",
    "no_answer": "Не отвечает",
    "booked": "Записан",
    "refused": "Отказался",
}
# Подсветка карточки пациента по статусу обзвона — полупрозрачная, только для
# понимания на глаз, не перекрывает текст. "Записан" подсвечивается зелёным
# только если в CRM ДЕЙСТВИТЕЛЬНО есть предстоящий визит (см. has_upcoming_visit
# ниже) — просто пометка менеджером без факта в CRM не красит карточку.
DORMANT_STATUS_TONE = {
    "no_answer": "tone-yellow",
    "refused": "tone-red",
}


def _is_blacklisted(raw_json: str | None) -> bool:
    if not raw_json:
        return False
    try:
        data = json.loads(raw_json)
    except (TypeError, ValueError):
        return False
    for t in data.get("tags") or []:
        low = str(t).lower()
        if any(h in low for h in _BLACKLIST_TAG_HINTS):
            return True
    return False


def _parse_date_only(s: str | None):
    if not s:
        return None
    try:
        return datetime.strptime(s[:10], "%Y-%m-%d").date()
    except ValueError:
        return None


def _dormant_data(date_from: str, date_to: str) -> dict:
    with get_db() as conn:
        clients = conn.execute("SELECT crm_id, phone, name, raw_json FROM crm_clients").fetchall()
        client_by_id = {c["crm_id"]: c for c in clients}

        visits = conn.execute(
            "SELECT client_crm_id, visit_datetime FROM crm_visits WHERE deleted = 0 ORDER BY visit_datetime"
        ).fetchall()
        visits_by_client: dict = {}
        for v in visits:
            cid = v["client_crm_id"]
            if cid is None:
                continue
            visits_by_client.setdefault(cid, []).append(v["visit_datetime"] or "")

        payments = conn.execute("SELECT client_crm_id, amount FROM crm_payments").fetchall()
        revenue_by_client: dict = {}
        for p in payments:
            cid = p["client_crm_id"]
            if cid is None:
                continue
            revenue_by_client[cid] = revenue_by_client.get(cid, 0.0) + (p["amount"] or 0.0)

        outreach = conn.execute("SELECT client_crm_id, status, note FROM dormant_outreach").fetchall()
        outreach_by_client = {o["client_crm_id"]: o for o in outreach}

        today = datetime.utcnow().date()
        cutoff = today - timedelta(days=DORMANT_DAYS)

        dormant_rows = []
        reactivated_in_period = 0
        patients_with_repeat = 0
        patients_total = 0
        ltv_values = []

        for cid, raw_dates in visits_by_client.items():
            dates = sorted(d for d in raw_dates if d)
            if not dates:
                continue
            patients_total += 1
            revenue = revenue_by_client.get(cid, 0.0)
            if revenue > 0:
                ltv_values.append(revenue)
            if len(dates) > 1:
                patients_with_repeat += 1

            # Реактивация за период: визит в периоде, перед которым был разрыв > 180 дней
            # с предыдущим визитом того же пациента.
            for i in range(1, len(dates)):
                prev_d, cur_d = _parse_date_only(dates[i - 1]), _parse_date_only(dates[i])
                if not prev_d or not cur_d:
                    continue
                if (cur_d - prev_d).days > DORMANT_DAYS and date_from <= dates[i][:10] <= date_to:
                    reactivated_in_period += 1

            # Прошедшие и будущие визиты считаем отдельно: только что назначенный
            # (но ещё не состоявшийся) визит НЕ должен мгновенно выкидывать пациента
            # из списка спящих — иначе подсветка "записан" никогда не будет видна
            # (пациент пропадёт из списка раньше, чем менеджер её увидит).
            past_dates = [d for d in dates if (_parse_date_only(d) or today) <= today]
            has_upcoming_visit = any((_parse_date_only(d) or today) > today for d in dates)
            if not past_dates:
                continue
            last_visit_d = _parse_date_only(past_dates[-1])
            if last_visit_d and last_visit_d < cutoff and revenue > 0:
                client = client_by_id.get(cid)
                if client and _is_blacklisted(client["raw_json"]):
                    continue
                o = outreach_by_client.get(cid)
                status = o["status"] if o and o["status"] in VALID_DORMANT_STATUSES else "new"
                tone = DORMANT_STATUS_TONE.get(status)
                if status == "booked" and has_upcoming_visit:
                    tone = "tone-green"
                dormant_rows.append(
                    {
                        "client_crm_id": cid,
                        "name": (client["name"] if client else None) or "—",
                        "phone": (client["phone"] if client else None) or "—",
                        "last_visit": past_dates[-1][:10],
                        "days_inactive": (today - last_visit_d).days,
                        "ltv": round(revenue, 2),
                        "status": status,
                        "note": (o["note"] if o else "") or "",
                        "has_upcoming_visit": has_upcoming_visit,
                        "tone": tone,
                    }
                )

        dormant_rows.sort(key=lambda r: -r["ltv"])

        avg_ltv = round(sum(ltv_values) / len(ltv_values), 2) if ltv_values else 0.0
        repeat_rate = round(patients_with_repeat / patients_total * 100, 1) if patients_total else 0.0

        return {
            "rows": dormant_rows,
            "dormant_count": len(dormant_rows),
            "reactivated_in_period": reactivated_in_period,
            "avg_ltv": avg_ltv,
            "repeat_rate": repeat_rate,
            "patients_total": patients_total,
            "status_labels": DORMANT_STATUS_LABELS,
        }


@app.get("/dormant", response_class=HTMLResponse)
async def dormant_page(request: Request):
    date_from, date_to = _parse_period(request)
    data = _dormant_data(date_from, date_to)
    period_mode = _detect_period_mode(date_from, date_to)
    return templates.TemplateResponse(
        "dormant.html",
        {
            "request": request, "data": data, "date_from": date_from, "date_to": date_to,
            "months": _recent_months(), "years": _recent_years(), "period_mode": period_mode,
            "current_month_value": date_from[:7], "current_year_value": date_from[:4],
            "period_label": _period_label(date_from, date_to, period_mode),
        },
    )


@app.post("/dormant/status")
async def update_dormant_status(request: Request):
    form = await request.form()
    try:
        client_crm_id = int(form.get("client_crm_id"))
    except (TypeError, ValueError):
        raise HTTPException(400)
    status = (form.get("status") or "").strip()
    if status not in VALID_DORMANT_STATUSES:
        raise HTTPException(400)
    upsert_dormant_status({"client_crm_id": client_crm_id, "status": status, "note": None})
    return RedirectResponse(url="/dormant", status_code=303)


@app.get("/calls", response_class=HTMLResponse)
async def calls_page(request: Request):
    date_from, date_to = _parse_period(request)
    with get_db() as conn:
        raw_calls = conn.execute(
            """
            SELECT c.*, (
                SELECT 1 FROM crm_clients cl WHERE cl.phone_norm = c.phone_norm LIMIT 1
            ) AS matched
            FROM calls c
            WHERE substr(started_at,1,10) BETWEEN ? AND ?
            ORDER BY started_at DESC
            LIMIT 200
            """,
            (date_from, date_to),
        ).fetchall()
    # Источник — человекочитаемым словом (как на воронке), а не сырым тегом calltouch.
    calls = [
        {
            "started_at": c["started_at"],
            "phone": c["phone"],
            "source_label": _humanize_source(c["source"], c["medium"]),
            "campaign": c["campaign"],
            "duration": c["duration"],
            "status": c["status"],
            "matched": c["matched"],
            "record_url": c["record_url"],
        }
        for c in raw_calls
    ]
    period_mode = _detect_calls_period_mode(date_from, date_to)
    return templates.TemplateResponse(
        "calls.html",
        {
            "request": request, "calls": calls, "date_from": date_from, "date_to": date_to,
            "weeks": _recent_weeks(), "months": _recent_months(), "period_mode": period_mode,
            "current_month_value": date_from[:7], "current_week_value": date_from,
            "period_label": _period_label(date_from, date_to, period_mode),
        },
    )
