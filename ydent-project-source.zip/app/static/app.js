// Живое обновление: как только приходит вебхук, сервер шлёт событие через SSE,
// и страница просто мягко перезагружается (данные лёгкие, соединение локальное).
(function () {
  if (!window.EventSource) return;
  var es = new EventSource("/events");
  es.addEventListener("refresh", function () {
    // небольшая задержка, чтобы не моргать при частых событиях подряд
    clearTimeout(window.__refreshTimer);
    window.__refreshTimer = setTimeout(function () {
      window.location.reload();
    }, 800);
  });
})();

// --- Общий выбор периода (Месяц / Год / Свой период) — используется и на
// воронке, и на каналах, чтобы не дублировать логику на каждой странице. ---
function navigateWithPeriod(from, to) {
  var url = new URL(window.location.href);
  url.searchParams.set("from", from);
  url.searchParams.set("to", to);
  window.location.href = url.toString();
}
// Общий помощник для полей вне формы периода (например «Канал» на воронке) —
// применяет фильтр сразу же, сохраняя остальные текущие параметры (период и т.п.).
function setQueryParam(name, value) {
  var url = new URL(window.location.href);
  if (value) {
    url.searchParams.set(name, value);
  } else {
    url.searchParams.delete(name);
  }
  window.location.href = url.toString();
}
function periodSetWeek(value) {
  if (!value) return;
  var start = new Date(value + "T00:00:00");
  var end = new Date(start.getTime() + 6 * 24 * 60 * 60 * 1000);
  function fmt(d) { return d.toISOString().slice(0, 10); }
  navigateWithPeriod(fmt(start), fmt(end));
}
function periodSetMonth(selectEl) {
  var val = selectEl.value;
  if (!val) return;
  var parts = val.split("-").map(Number);
  var y = parts[0], m = parts[1];
  var from = val + "-01";
  var lastDay = new Date(y, m, 0).getDate();
  var to = val + "-" + String(lastDay).padStart(2, "0");
  navigateWithPeriod(from, to);
}
function periodSetYear(year) {
  if (!year) return;
  var from = year + "-01-01";
  var todayYear = new Date().getFullYear();
  var to = (Number(year) === todayYear) ? new Date().toISOString().slice(0, 10) : year + "-12-31";
  navigateWithPeriod(from, to);
}
// Переключатель вкладок Месяц/Год/Свой период — сами вкладки Месяц/Год
// (Неделя на «Звонках») всегда видны на странице и применяются сразу через
// onchange у соответствующего select'а (periodSetMonth/periodSetYear/
// periodSetWeek выше). «Свой период» — единственная вкладка, для которой
// нужны два поля дат и явное подтверждение, поэтому клик по ней открывает
// поп-ап (см. openPeriodModal ниже) вместо того, чтобы разворачивать поля
// на самой странице.
function setupPeriodToggle(toggleId, formSelector) {
  var toggle = document.getElementById(toggleId);
  var form = document.querySelector(formSelector);
  if (!toggle || !form) return;
  toggle.querySelectorAll("button[data-mode]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      toggle.querySelectorAll("button").forEach(function (b) { b.classList.remove("active"); });
      btn.classList.add("active");
      form.dataset.mode = btn.dataset.mode;
      if (btn.dataset.mode === "custom") openPeriodModal();
    });
  });
}

// --- Поп-ап «Свой период»: только два поля дат + кнопка «Показать» как
// подтверждение выбора. Месяц/Год/Неделя в поп-ап не выводятся — они всегда
// открыты на странице, в общей плашке фильтров. ---
function openPeriodModal() {
  var el = document.getElementById("period-modal");
  if (el) el.classList.add("open");
}
function closePeriodModal() {
  var el = document.getElementById("period-modal");
  if (el) el.classList.remove("open");
}
// Общий обработчик Escape — закрывает любую открытую модалку на странице
// (поп-ап периода, drill-down по воронке и т.п.), чтобы не дублировать
// одинаковые keydown-слушатели на каждой странице отдельно.
document.addEventListener("keydown", function (e) {
  if (e.key !== "Escape") return;
  document.querySelectorAll(".modal-overlay.open").forEach(function (el) {
    el.classList.remove("open");
  });
});

// --- Раскрывающиеся плашки (список каналов и т.п.) ---
function toggleAccordion(headEl) {
  var card = headEl.closest(".accordion-card");
  if (card) card.classList.toggle("open");
}

// --- Инлайн-редактирование строки ручного расхода на рекламу ---
function toggleSpendEdit(id) {
  var row = document.getElementById("spend-view-" + id);
  var edit = document.getElementById("spend-edit-" + id);
  if (!row || !edit) return;
  var editing = edit.style.display !== "none";
  edit.style.display = editing ? "none" : "";
  row.style.display = editing ? "" : "none";
}
